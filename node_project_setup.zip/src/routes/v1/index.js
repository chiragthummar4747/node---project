const express = require('express');
const authRoute = require('./auth.route');
const userRoute = require('./user.route');
const docsRoute = require('./docs.route');
const countryRoute = require('./country.route');
const cityRoute = require('./city.route');
const config = require('../../config/config');
const roleRouter = require('../../routes/v1/role.route');
const clinicRoute = require('./clinic.route');
const categoriesRoute = require('./categories.route');
const dailytoken = require('./dailytoken.route');
const clinicServiceRoute = require('./clinicService.route');
const service = require('./service.route');
const servicefeedback = require('./servicefeedback.route')

const router = express.Router();

const defaultRoutes = [
  {
    path: '/auth',
    route: authRoute,
  },
  {
    path: '/users',
    route: userRoute,
  },
  {
    path: '/role',
    route: roleRouter,
  },
  {
    path: '/country',
    route: countryRoute,
  },
  {
    path: '/city',
    route: cityRoute,
  },
  {
    path: '/clinic',
    route: clinicRoute,
  },
  {
    path: '/categories',
    route: categoriesRoute,
  },
  {
    path: '/dailytoken',
    route: dailytoken,
  },
  {
    path: '/clinicService',
    route: clinicServiceRoute,
  },
  {
    path: '/service',
    route: service,
  },
  {
    path: '/servicefeedback',
    route: servicefeedback
  },
];

const devRoutes = [
  // routes available only in development mode
  {
    path: '/docs',
    route: docsRoute,
  },
];

defaultRoutes.forEach((route) => {
  router.use(route.path, route.route);
});

/* istanbul ignore next */
if (config.env === 'development') {
  devRoutes.forEach((route) => {
    router.use(route.path, route.route);
  });
}

module.exports = router;
