const express = require('express');
const validate = require('../../middlewares/validate');
const serviceValidation = require('../../validations/service.validation');
const serviceController = require('../../controllers/service.controller');

const router = express.Router();

router
  .route('/')
  .post(validate(serviceValidation.createservices), serviceController.createservices)
  .get(serviceController.getService);

module.exports = router;
