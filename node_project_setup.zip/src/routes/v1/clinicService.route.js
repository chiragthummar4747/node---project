const express = require('express');
const validate = require('../../middlewares/validate');
const clinicServiceValidation = require('../../validations/clinicService.validation');
const clinicServiceController = require('../../controllers/clinicService.controller');

const router = express.Router();

router
    .route('/')
    .post(validate(clinicServiceValidation.createClinicService), clinicServiceController.createClinicService)
    .get(validate(clinicServiceValidation.getClinicService), clinicServiceController.getClinicService)

module.exports = router;
