const express = require('express');
const validate = require('../../middlewares/validate');
const categoriesValidation = require('../../validations/categories.validation');
const categoriesController = require('../../controllers/categories.controller');
const imageUpload = require('../../middlewares/upload');

const router = express.Router();

router
  .route('/')
  .post(
    imageUpload.single('categoriesImage'),
    validate(categoriesValidation.createCategories),
    categoriesController.createCategories
  )
  .get(validate(categoriesValidation.getCategories), categoriesController.getCategories);

router
  .route('/:id')
  .get(validate(categoriesValidation.getCategoriesById), categoriesController.getCategoriesById)
  .put(
    imageUpload.single('categoriesImage'),
    validate(categoriesValidation.updateCategories),
    categoriesController.updateCategories
  )
  .delete(validate(categoriesValidation.deleteCategories), categoriesController.deleteCategories);


module.exports = router;
