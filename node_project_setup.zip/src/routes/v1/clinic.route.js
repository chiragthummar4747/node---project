const express = require('express');
const validate = require('../../middlewares/validate');
const clinicvalidation = require('../../validations/clinic.validation');
const cliniccontroller = require('../../controllers/clinic.controller');
const imageUpload = require('../../middlewares/upload');

const router = express.Router();

router
  .route('/')
  .post(imageUpload.single('clinicImage'), validate(clinicvalidation.createclinic), cliniccontroller.createclinic)
  .get(validate(clinicvalidation.getAllclinic), cliniccontroller.getAllclinic);

router
  .route('/:id')
  .delete(validate(clinicvalidation.deleteclinic), cliniccontroller.deleteclinic)
  .get(validate(clinicvalidation.getclinicuser), cliniccontroller.getclinicuser)
  .put(imageUpload.single('clinicImage'),validate(clinicvalidation.updateclinic), cliniccontroller.updateclinic);

router
  .route('/findtoken/:id')
  .get(validate(clinicvalidation.getclinictoken),cliniccontroller.getclinictoken)

router
  .route('/location/getcity')
  .get(validate(clinicvalidation.getlocationwiseclinic),cliniccontroller.getlocationwiseclinic)

module.exports = router;
