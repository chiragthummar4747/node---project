const express = require('express');
const validate = require('../../middlewares/validate');
const dailytokenValidation = require('../../validations/dailytoken.validation');
const dailytokenController = require('../../controllers/dailytoken.controller');
const socketIO = require('../../services/socket.io');
const {auth} = require('../../middlewares/auth')

const router = express.Router();

router
  .route('/')
  .post(validate(dailytokenValidation.bookingtoken), dailytokenController.bookingtoken)
  .get(validate(dailytokenValidation.getTokenData), dailytokenController.getTokenData);

router.route('/:clinic').put(validate(dailytokenValidation.changeTokenStatus), dailytokenController.changeTokenStatus);

router.route('/cancelToken/:clinic').put(validate(dailytokenValidation.cancelToken), dailytokenController.cancelToken);

router.route('/currentToken').get(dailytokenController.currentToken);
module.exports = router;
