const express = require('express');
const validate = require('../../middlewares/validate');
const cityValidation = require('../../validations/city.validation');
const cityController = require('../../controllers/city.controller');

const router = express.Router();

router
  .route('/')
  // .post(cityController.AllCityList)
  .post(validate(cityValidation.createCity), cityController.createCity)
  .get(validate(cityValidation.getCity), cityController.getCity);

router
  .route('/:cityId')
  .get(validate(cityValidation.getCityById), cityController.getCityById)
  .put(validate(cityValidation.updateCity), cityController.updateCity)
  .delete(validate(cityValidation.deleteCity), cityController.deleteCity);

router.route('/country/:countryID').get(validate(cityValidation.getCityByCountry), cityController.getCityByCountry);

module.exports = router;
