const express = require('express');
const validate = require('../../middlewares/validate');
const countryValidation = require('../../validations/country.validation');
const countryController = require('../../controllers/country.controller');

const router = express.Router();

router
  .route('/')
  .post(validate(countryValidation.createCountry), countryController.createCountry)
  .get(validate(countryValidation.getCountry), countryController.getCountry);

router
  .route('/:countryId')
  .get(validate(countryValidation.getCountryById), countryController.getCountryById)
  .put(validate(countryValidation.updateCountry), countryController.updateCountry)
  .delete(validate(countryValidation.deleteCountry), countryController.deleteCountry);

module.exports = router;
