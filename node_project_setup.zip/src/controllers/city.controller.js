const httpStatus = require('http-status');
const catchAsync = require('../utils/catchAsync');
const pick = require('../utils/pick');
const ApiError = require('../utils/ApiError');
const cityService = require('../services/city.service');
const cityList = require('../seeder/seeder');

// Using Seeder insert data in 'city' collection.
const AllCityList = catchAsync(async (req, res) => {
  const allcitylist = await cityList.allCityList();
  res.status(httpStatus.OK).json({ success: true, msg: 'City data created successfully...!' });
});
// End: seeder

// POST: Add new city in database
const createCity = catchAsync(async (req, res) => {
  const cityData = await cityService.createCity(req.body);
  res.status(httpStatus.OK).json({ success: true, msg: 'City created successfully', cityData });
});

// GET: Show all city data
const getCity = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['city_name']);
  filter.isActive = true;
  const citySearch = filter.city_name;
  filter.city_name = { $regex: `${filter.city_name}` };
  const options = pick(req.query, ['sortBy', 'limit', 'page']);
  options.populate = 'country';
  const city = await cityService.getCity(filter, options);
  res.status(httpStatus.OK).json({ success: true, msg: 'CityData', Search: citySearch, city });
});

// GET: show city data by ObjectID
const getCityById = catchAsync(async (req, res) => {
  const getdataById = await cityService.getCityById(req.params.cityId);
  // Check city are found or not in database
  if (!getdataById) {
    throw new ApiError(httpStatus.NOT_FOUND, 'City are not Found');
  }
  res.status(httpStatus.OK).json({ success: true, msg: 'City find Successfully...!', getdataById });
});

// GET: Show city data by Country
const getCityByCountry = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['city_name']);
  filter.country = req.params.countryID;
  filter.isActive = true;
  const citySearch = filter.city_name;
  filter.city_name = { $regex: `${filter.city_name}` };
  const options = pick(req.query, ['sortBy', 'limit', 'page']);
  options.populate = 'country';
  const city = await cityService.getCity(filter, options);
  res
    .status(httpStatus.OK)
    .json({ success: true, msg: 'CityData', Country: req.params.countryID, Search: citySearch, city });
});

// PUT: Update city data by ObjectID
const updateCity = catchAsync(async (req, res) => {
  const getdataById = await cityService.getCityById(req.params.cityId);
  // Check city are found or not in database
  if (!getdataById) {
    throw new ApiError(httpStatus.NOT_FOUND, 'City are not Found');
  }
  const updateData = await cityService.updateCity(req.params.cityId, req.body);
  res.status(httpStatus.OK).json({ success: true, msg: 'City Data Updated successfully', updateData: req.body });
});

// DELETE: Delete City data by ObjectID
const deleteCity = catchAsync(async (req, res) => {
  const getdataById = await cityService.getCityById(req.params.cityId);
  // Check city are found or not in database
  if (!getdataById) {
    throw new ApiError(httpStatus.NOT_FOUND, 'City are not Found');
  }
  const deleteData = await cityService.deleteCity(req.params.cityId);
  res.status(httpStatus.OK).json({ success: true, msg: 'City Data deleted successfully', deleteData });
});

// All Modules are Exports from here 👇
module.exports = {
  AllCityList,
  createCity,
  getCity,
  getCityById,
  getCityByCountry,
  updateCity,
  deleteCity,
};
