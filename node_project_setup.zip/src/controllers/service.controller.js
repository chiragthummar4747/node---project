const httpStatus = require('http-status');
const ApiError = require('../utils/ApiError');
const catchAsync = require('../utils/catchAsync');
const { serviceService } = require('../services');

// POST: Create a Services
const createservices = catchAsync(async (req, res) => {
  const servicedata = await serviceService.createservice({ ...req.body });
  res.status(httpStatus.CREATED).json({ success: true, msg: 'service created successfully...!', data: servicedata });
});

// GET: Show all data from service Table
const getService = catchAsync(async (req, res) => {
  const getData = await serviceService.getService();
  res.status(httpStatus.OK).json({ success: true, msg: 'Get all data from service collection..!', data: getData });
});

// All Modules are Exports from here 👇
module.exports = {
  createservices,
  getService,
};
