const catchAsync = require('../utils/catchAsync');
const ApiError = require('../utils/ApiError');
const httpStatus = require('http-status');
const clinicservice = require('../services/clinic.service');
const pick = require('../utils/pick');

// POST: Create a clinic
const createclinic = catchAsync(async (req, res) => {
  const arrayData = req.body.service;
  const jsonArrayData = JSON.parse(arrayData);
  const objectData = req.body.openingHours;
  const jsonObjectData = JSON.parse(objectData);
  console.log('jsonObjectData : : :', jsonObjectData);
  const imageURL = `http://localhost:3001/${req.file.filename}`;
  const clinic = await clinicservice.createclinics({ ...req.body, clinicImage: imageURL, openingHours: jsonObjectData, service: jsonArrayData });
  res.status(httpStatus.CREATED).json({ success: true, msg: 'clinicuser create sucessfully', data: clinic });
});

// GET: show all clinic data
const getAllclinic = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['clinicName']);
  const clinicsearch = filter.clinicName;
  filter.clinicName = { $regex: `${filter.clinicName}` };
  const options = pick(req.query, ['sortBy', 'limit', 'page']);
  options.populate = 'category, service';
  const clinic = await clinicservice.getClinic(filter, options);
  res.status(200).json({ sucess: true, msg: 'All clinic data get sucessfully', Search: clinicsearch, data: clinic });
});

// GET: Show clinic data by ObjectID
const getclinicuser = catchAsync(async (req, res) => {
  const findById = await clinicservice.findbyid(req.params.id);
  // Check clinic are found or not in database
  if (!findById) {
    throw new ApiError(httpStatus.NOT_FOUND, 'clinic are not found');
  }
  const findidandgetdata = await clinicservice.getdata(findById._id);
  res.status(200).json({ sucess: true, msg: 'clinic data find sucessfully', data: findidandgetdata });
});

// PUT: Update clinic data by ObjectID
const updateclinic = catchAsync(async (req, res) => {
  const findById = await clinicservice.findbyid(req.params.id);
  if (!findById) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Clinic Are not Found.');
  }
  if (req.file && req.body.openingHours) {
    const objectData = req.body.openingHours;
    const jsonObjectData = JSON.parse(objectData);
    const imageURL = `http://localhost:3001/${req.file.filename}`;
    const updateuserclinic = await clinicservice.updateClinic(findById, {
      ...req.body,
      clinicImage: imageURL,
      openingHours: jsonObjectData,
    });
    res.status(200).json({ sucess: true, msg: 'update clinic sucessfully', update: updateuserclinic });
  }
  // Check image are Update or not.
  else if (req.file) {
    const imageURL = `http://localhost:3001/${req.file.filename}`;
    const updateuserclinic = await clinicservice.updateClinic(findById, { ...req.body, clinicImage: imageURL });
    res.status(200).json({ sucess: true, msg: 'update clinic sucessfully', update: updateuserclinic });
  }
  // Check Opening Hours are Update or not
  else if (req.body.openingHours) {
    const objectData = req.body.openingHours;
    const jsonObjectData = JSON.parse(objectData);
    const updateuserclinic = await clinicservice.updateClinic(findById, {
      ...req.body,
      openingHours: jsonObjectData,
    });
    res.status(200).json({ sucess: true, msg: 'update clinic sucessfully', update: updateuserclinic });
  } else {
    const updateuserclinic = await clinicservice.updateClinic(findById, { ...req.body });
    res.status(200).json({ sucess: true, msg: 'update clinic sucessfully', update: updateuserclinic });
  }
});

// GET: Show clinic Token
const getclinictoken = catchAsync(async (req, res) => {
  const findById = await clinicservice.findbyid(req.params.id);
  // Check clinic are found or not in database
  if (!findById) {
    throw new ApiError(httpStatus.NOT_FOUND, 'clinic are not found');
  }
  const booktoken = await clinicservice.findtoken(findbyid.dailyToken);
  res.status(200).json({ sucess: true, msg: 'clinic token get sucessfully', clinictoken: findbyid.dailyToken });
});

// GET: show clinic by Location
const getlocationwiseclinic = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['clinicAdress']);
  const clinicsearch = filter.clinicAdress;
  filter.clinicAdress = { $regex: `${filter.clinicAdress}` };
  const options = pick(req.query, ['sortBy', 'limit', 'page']);
  options.populate = 'categorie';
  const clinic = await clinicservice.getClinic(filter, options);
  res.status(200).json({ sucess: true, msg: ' clinic data get sucessfully', Search: clinicsearch, data: clinic });
});

// DELETE: Delete clinic by ObjectID
const deleteclinic = catchAsync(async (req, res) => {
  const findById = await clinicservice.findbyid(req.params.id);
  // Check clinic are found or not in database
  if (!findById) {
    throw new ApiError(httpStatus.NOT_FOUND, 'clinic are not found');
  }
  await clinicservice.deleteclinic(req.params);
  res.status(200).json({ success: true, msg: 'clinic delete sucessfully' });
});

// All Modules are Exports from here 👇
module.exports = {
  createclinic,
  getAllclinic,
  getclinicuser,
  getclinictoken,
  updateclinic,
  getlocationwiseclinic,
  deleteclinic,
};
