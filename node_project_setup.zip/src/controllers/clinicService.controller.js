const httpStatus = require('http-status');
const catchAsync = require('../utils/catchAsync');
const pick = require('../utils/pick');
const ApiError = require('../utils/ApiError');
const clinicServiceService = require('../services/clinicService.service');

// POST: create Clinic Service
const createClinicService = catchAsync(async (req, res) => {
  const clinicid = await clinicServiceService.findbyclinicid(req.body.clinic);
  // Check clinic are found or not in database
  if (!clinicid) {
    throw new ApiError(httpStatus.NOT_FOUND, 'clinic are Not Found');
  }
  const serviceid = await clinicServiceService.findbyserviceid(req.body.service);
  // Check Service are found or not in database
  if (!serviceid) {
    throw new ApiError(httpStatus.NOT_FOUND, 'service are Not Found');
  }
  const clinicService = await clinicServiceService.createClinicService(req.body);
  res
    .status(httpStatus.CREATED)
    .json({ success: true, msg: 'ClinicService are created Successfully...!', data: clinicService });
});

// GET: Show All clinic Service
const getClinicService = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['clinic']);
  const options = pick(req.query, ['sortBy', 'limit', 'page']);
  options.populate = 'clinic, service';
  const getData = await clinicServiceService.getClinicService(filter, options);
  res.status(httpStatus.OK).json({ success: true, msg: "Get ClinicService's data Successfully...!", data: getData });
});

// All Modules are Exports from here 👇
module.exports = {
  createClinicService,
  getClinicService,
};
