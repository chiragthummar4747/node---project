const httpStatus = require('http-status');
const catchAsync = require('../utils/catchAsync');
const pick = require('../utils/pick');
const ApiError = require('../utils/ApiError');
const countryServices = require('../services/country.service');

// POST: Create a country
const createCountry = catchAsync(async (req, res) => {
  const countryData = await countryServices.createCountry({ ...req.body });
  res.status(httpStatus.CREATED).json({ success: true, msg: 'Country created successfully', countryData });
});

// GET: Show All country data from database
const getCountry = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['country_name']);
  filter.isActive = true;
  const countrySearch = filter.country_name;
  filter.country_name = { $regex: `${filter.country_name}` };
  const options = pick(req.query, ['sortBy', 'limit', 'page']);
  const country = await countryServices.getCountry(filter, options);
  res.status(httpStatus.OK).json({ success: true, msg: 'Country Data', Search: countrySearch, country });
});

// GET: Show Country data by ObjectID
const getCountryById = catchAsync(async (req, res) => {
  const getdataById = await countryServices.getCountryById(req.params.countryId);
  // Check Country are found or not in database
  if (!getdataById) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Country are not Found');
  }
  res.status(httpStatus.OK).json({ success: true, msg: 'Country Find successfully...!', getdataById });
});

// PUT: Update Country data by ObjectID
const updateCountry = catchAsync(async (req, res) => {
  const getdataById = await countryServices.getCountryById(req.params.countryId);
  // Check Country are found or not in database
  if (!getdataById) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Country are not Found');
  }
  const updateData = await countryServices.updateCountry(req.params.countryId, req.body);
  res.status(httpStatus.OK).json({ success: true, msg: 'Country Data Updated successfully', updateData });
});

// DELETE: Delete Country by ObjectID
const deleteCountry = catchAsync(async (req, res) => {
  const getdataById = await countryServices.getCountryById(req.params.countryId);
  // Check Country are found or not in database
  if (!getdataById) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Country are not Found');
  }
  const deleteData = await countryServices.deleteCountry(req.params.countryId);
  res.status(httpStatus.OK).json({ success: true, msg: 'Country Data deleted successfully', deleteData });
});

// All Modules are Exports from here 👇
module.exports = {
  createCountry,
  getCountry,
  getCountryById,
  updateCountry,
  deleteCountry,
};
