const httpStatus = require('http-status');
const { City, Country } = require('../models');
const ApiError = require('../utils/ApiError');

// create city in 'city' collection.
const createCity = async (cityData) => {
  const findCountry = await Country.findById({ _id: cityData.country });
  if (!findCountry) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Country are not found, Please enter valid CountryID');
  }
  const findData = await alreadyExistCity(cityData);
  return City.create({ ...findData });
};

// get all city and search city in 'city' collection.
const getCity = async (filter, options) => {
  return City.paginate(filter, options);
};

// get city by City's ObjectID 'city' collection.
const getCityById = async (id) => {
  return City.findById(id).populate('country');
};

// get city By Country from 'city' collection.
const getCityByCountry = async (filter, options) => {
  return City.paginate(filter, options);
};

// UPDATE city in 'city' collection.
const updateCity = async (id, data) => {
  const cityExist = await alreadyExistCity(data);
  const updateData = await City.updateOne(
    { _id: id },
    {
      $set: {
        ...data,
      },
    },
    {
      new: true,
    }
  );
  return updateData;
};

// DELETE city in 'city' collection.
const deleteCity = async (id) => {
  return City.deleteOne({ _id: id });
};

// check city are already USED or NOT in 'city' collection.
const alreadyExistCity = async (citydata) => {
  const finddata = await City.find({
    city_name: { $eq: citydata.city_name },
    country: { $eq: citydata.country },
  });
  if (finddata.length) {
    throw new ApiError(httpStatus.ALREADY_REPORTED, 'City are already Used');
  }
  return citydata;
};

// All Modules are Exports from here 👇
module.exports = {
  createCity,
  getCity,
  getCityById,
  getCityByCountry,
  updateCity,
  deleteCity,
  alreadyExistCity,
};
