const httpStatus = require('http-status');
const { service } = require('../models');

// POST: Create a Services
const createservice = async (data) => {
  return service.create(data);
};

// GET: Show all data from service Table
const getService = async () => {
  return service.find();
};

// All Modules are Exports from here 👇
module.exports = {
  createservice,
  getService,
};
