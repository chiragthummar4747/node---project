const httpStatus = require('http-status');
const { Categories } = require('../models');
const ApiError = require('../utils/ApiError');

// create category in 'categories' collection.
const createCategories = async (categoriesData) => {
  return Categories.create(categoriesData);
};

// get all category and search category in 'categories' collection.
const getCategories = async () => {
  return Categories.find();
};

// find category id
const getCategoriesById = async (id) => {
  return Categories.findById(id);
};

// UPDATE category in 'categories' collection
const updateCategories = async (id, data) => {
  return Categories.updateOne(
    { _id: id },
    {
      $set: {
        ...data,
      },
    },
    {
      new: true,
    }
  );
};

// DELETE category in 'categories' collection
const deleteCategories = async (id) => {
  return Categories.deleteOne({ _id: id });
};

// All Modules are Exports from here 👇
module.exports = {
  createCategories,
  getCategories,
  getCategoriesById,
  updateCategories,
  deleteCategories,
};
