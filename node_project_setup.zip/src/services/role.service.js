const { role } = require('../models');
const httpStatus = require('http-status');
const ApiError = require('../utils/ApiError');

// create  role collection
const createuser = async (payload) => {
  const finddata = await role.findOne({ role: payload.role });
  // find role data from database.
  if (finddata) {
    throw new ApiError(httpStatus.ALREADY_REPORTED, 'role are already use');
  }
  return role.create(payload);
};

// All Modules are Exports from here 👇
module.exports = {
  createuser,
};
