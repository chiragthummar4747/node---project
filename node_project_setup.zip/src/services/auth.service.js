const httpStatus = require('http-status');
const tokenService = require('./token.service');
const userService = require('./user.service');
const Token = require('../models/token.model');
const ApiError = require('../utils/ApiError');
const { tokenTypes } = require('../config/tokens');

/**
 * Login with username and password
 * @param {string} email
 * @param {string} password
 * @returns {Promise<User>}
 */
const loginUserWithEmailAndPassword = async (email, password) => {
  const user = await userService.getUserByEmail(email);
  if (!user || !(await user.isPasswordMatch(password))) {
    throw new ApiError(httpStatus.UNAUTHORIZED, 'Incorrect email or password');
  }
  return user;
};

/**
 * Logout
 * @param {string} refreshToken
 * @returns {Promise}
 */
const logout = async (refreshToken) => {
  const refreshTokenDoc = await Token.findOne({ token: refreshToken, type: tokenTypes.REFRESH, blacklisted: false });
  if (!refreshTokenDoc) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Not found');
  }
  await refreshTokenDoc.remove();
};

/**
 * Refresh auth tokens
 * @param {string} refreshToken
 * @returns {Promise<Object>}
 */
const refreshAuth = async (refreshToken) => {
  try {
    const refreshTokenDoc = await tokenService.verifyToken(refreshToken, tokenTypes.REFRESH);
    const user = await userService.getUserById(refreshTokenDoc.user);
    if (!user) {
      throw new Error();
    }
    await refreshTokenDoc.remove();
    return tokenService.generateAuthTokens(user);
  } catch (error) {
    throw new ApiError(httpStatus.UNAUTHORIZED, 'Please authenticate');
  }
};

/**
 * Reset password
 * @param {string} resetPasswordToken
 * @param {string} newPassword
 * @returns {Promise}
 */
const resetPassword = async (resetPasswordToken, newPassword) => {
  try {
    const resetPasswordTokenDoc = await tokenService.verifyToken(resetPasswordToken, tokenTypes.RESET_PASSWORD);
    const user = await userService.getUserById(resetPasswordTokenDoc.user);
    if (!user) {
      throw new Error();
    }
    await userService.updateUserById(user.id, { password: newPassword });
    await Token.deleteMany({ user: user.id, type: tokenTypes.RESET_PASSWORD });
  } catch (error) {
    throw new ApiError(httpStatus.UNAUTHORIZED, 'Password reset failed');
  }
};

/**
 * Verify email
 * @param {string} verifymobileNoToken
 * @returns {Promise}
 */
const verifmobile_no = async (verifymobileNoToken) => {
  try {
    const verifyMobile_noTokenDoc = await tokenService.verifyotp(verifymobileNoToken, tokenTypes.VERIFY_OTP);
    const user = await userService.getUserById(verifyMobile_noTokenDoc.user);
    const TokenOTP = await Token.findOne({token:verifymobileNoToken})
    const otpcreatetime = TokenOTP.createdAt
    const currentOtptime = new Date();
    const differenceTime = (currentOtptime - otpcreatetime) / 60000;
    if (differenceTime < 5) {
      await Token.deleteMany({ user: user.id, type: tokenTypes.VERIFY_OTP });
      return await userService.updateUserById(user.id, { isActive: true });
    }
    else {
      throw new ApiError(httpStatus.NOT_FOUND, 'your otp is expire');
    }
  } catch (error) {
    throw new ApiError(httpStatus.UNAUTHORIZED, error);
  }
  // try {
  //   const verifyMobile_noTokenDoc = await tokenService.verifyotp(verifymobileNoToken, tokenTypes.VERIFY_OTP);
  //   const user = await userService.getUserById(verifyMobile_noTokenDoc.user);
  //   await Token.deleteMany({ user: user.id, type: tokenTypes.VERIFY_OTP });
  //   console.log(user)
  //   return await userService.updateUserById(user.id, { isActive: true });
  // } catch (error) {
  //   throw new ApiError(httpStatus.UNAUTHORIZED, 'otp verification failed');
  // }
};

// All Modules are Exports from here 👇
module.exports = {
  loginUserWithEmailAndPassword,
  logout,
  refreshAuth,
  resetPassword,
  verifmobile_no,
};
