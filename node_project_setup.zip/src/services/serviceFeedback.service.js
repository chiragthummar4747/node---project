const httpStatus = require('http-status')
const { servicefeedback, clinic, dailytoken } = require('../models')
const ApiError = require('../utils/ApiError')
const service = require('../models/services.model')
const User = require('../models/user.model')

// create feedback 
const createfeedback = async (id, data) => {
    const findservice = await service.find({ _id: data.service })
    if (!findservice) {
        throw new ApiError(httpStatus.NOT_FOUND, 'service are not found')
    }
    const finddailytoken = await dailytoken.findOne({ tokenId: data.tokenId })
    if (!finddailytoken) {
        throw new ApiError(httpStatus.NOT_FOUND, 'tokenId are not found')
    }
    return servicefeedback.create(data)
}

// update feedback 
const updatefeedback = async ({ id }, data) => {
    const findservice = await service.find({ _id: data.service })
    if (!findservice) {
        throw new ApiError(httpStatus.NOT_FOUND, 'service are not found')
    }
    const finddailytoken = await dailytoken.findOne({ tokenId: data.tokenId })
    if (!finddailytoken) {
        throw new ApiError(httpStatus.NOT_FOUND, 'tokenId are not found')
    }
    const updateOne = servicefeedback.updateOne(
        { _id: id },
        {
            ...data
        },
        {
            new: true,
        }
    )
    return updateOne;
}

// delete feedback
const deletefeedback = async ({ id }) => {
    const finddailytoken = await servicefeedback.findOne({ _id: id })
    if (!finddailytoken) {
        throw new ApiError(httpStatus.NOT_FOUND, 'feedback id are not found')
    }
    return servicefeedback.findByIdAndDelete(id)
}

// find all feedback
const findallfeedback = async () => {
    return await servicefeedback.find().populate('user service')
}
module.exports = {
    createfeedback,
    updatefeedback,
    deletefeedback,
    findallfeedback
}