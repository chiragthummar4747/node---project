const httpStatus = require('http-status');
const ApiError = require('../utils/ApiError');
const mongoose = require('mongoose');
const auth = require('../middlewares/auth');
const clinic = require('../models/clinic.model');
const dailytoken = require('../models/dailytoken.model');
const dailytokenservices =  require('./dailytoken.service')

module.exports.socketIO = function (io) {
  // Authentication usage
  io.use(auth.authSocketIO);

// ***************************************
  // Token Book in clinic API
// ***************************************

  io.on('connection', async (socket) => {
    socket.on('bookToken', async function (data) {
      console.log('data : ', data)
      const ExistClinic = await dailytokenservices.findbyclinicid(data.clinic);
      // Check clinic are found or not in database
      if (!ExistClinic) {
        socket.emit('bookToken', 'Clinic are Not Found ❌')
        throw new ApiError(httpStatus.NOT_FOUND, 'Clinic are Not Found');
      }
      const ExistUser = await dailytokenservices.findbyuserid(data.user);
      // Check User are found or not in database
      if (!ExistUser) {
        socket.emit('bookToken', 'User are Not Found ❌')
        throw new ApiError(httpStatus.NOT_FOUND, 'User are Not Found');
      }
      const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      // Generate a Token ID
      function generateString(length) {
        let result = ' ';
        const charactersLength = characters.length;
        for (let i = 0; i < length; i++) {
          result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        return result;
      }
      const tokenbooking = await dailytokenservices.bookingtoken({ tokenId: generateString(8) }, data.clinic, data.user);
      socket.emit('bookToken', tokenbooking)
    });
  });
  io.on('disconnect', function () {
    console.log('You are Disconnected from socket .');
  });

// ***************************************
  // Current Token API using Socket.io
// ***************************************

  io.on('connection', async (socket) => {
    socket.on('currentToken', async function (data) {
      const clinicExist = await clinic.findById(data.clinic);
      if (!clinicExist) {
        socket.emit('currentToken',data.clinic)
        socket.emit('currentToken', 'Clinic are not Found ❌');
        throw new ApiError(httpStatus.NOT_FOUND, 'Clinic are not Found');
      }
      const currentToken = await dailytoken.findOne({ clinic: data.clinic, date: data.date, serviceStatus: 'Active' });
      if (currentToken) {
        socket.emit('currentToken', `Active Token No.: ${currentToken.tokenNo}`);
      } else {
        socket.emit('currentToken', 'Now no any Token are Active');
      }
    });
  });
  io.on('disconnet', function () {
    console.log('You are Disconnected from socket .');
  });
};
