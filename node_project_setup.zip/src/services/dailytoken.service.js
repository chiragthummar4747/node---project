const httpStatus = require('http-status');
const { dailytoken, clinic, User } = require('../models');
const ApiError = require('../utils/ApiError');
const moment = require('moment');
const { currentToken } = require('../validations/dailytoken.validation');

// create booking token in token collection
const bookingtoken = async ({ tokenId }, clinicid, user) => {
  const findbydata = await dailytoken.find({
    $and: [{ clinic: { $eq: clinicid } }, { user: { $eq: user } }],
  });
  if (findbydata.length == 0) {
    const data = await clinic.findOne({ _id: clinicid });
    const totaltoken = data.dailyToken;
    const findttalclinicrecord = await dailytoken.find({ clinic: clinicid })
    if (totaltoken > findttalclinicrecord.length) {
      const clinictokenNo = await dailytoken.find({ clinic: clinicid });
      if(clinictokenNo.length == 0){
        return dailytoken.create({ clinic: clinicid, user, tokenId, tokenNo: 1 });
      }
      else{
      const [lastrecord] = await dailytoken.find({ clinic: clinicid }).sort({ tokenNo: -1}).limit(1); 
      const index = lastrecord.tokenNo + 1
      return dailytoken.create({ clinic: clinicid, user, tokenId, tokenNo: index });
      }
    } else {
      throw new ApiError(httpStatus.NOT_ACCEPTABLE, 'All token book this clinic ');
    }
  }
  else {
    const booktokenuser = await dailytoken.find({
      $and: [{ clinic: { $eq: clinicid } }, { user: { $eq: user } }],
    });
    return booktokenuser
  }
};

// get booking token data in token collection
const getTokenData = async (filter, options) => {
  return dailytoken.paginate(filter, options);
};

// find token
const findbytoken = async (token) => {
  return dailytoken.find({ token });
};

// find clinic id in clinic collection
const findbyclinicid = async (id) => {
  return clinic.findById(id);
};

// find user id in user colletion
const findbyuserid = async (id) => {
  return User.findById(id);
};

// PUT: Show Current Token Api and Update serviceStatus
const changeTokenStatus = async (id) => {
  const showtoken = await dailytoken.findOne({ clinic: id, serviceStatus: 'Pending' });
  // pending token are found or not.
  if (!(showtoken == null)) {
    const status = await dailytoken.findOneAndUpdate(
      { clinic: id, serviceStatus: showtoken.serviceStatus },
      { $set: { serviceStatus: 'Active' } },
      { new: true }
    );
    const lastactive = await dailytoken.findOne({ clinic: id, serviceStatus: 'Active' }).skip(1);
    // Active token are found or not.
    if (!(lastactive == null)) {
      const status = await dailytoken.findOneAndUpdate(
        { clinic: id, serviceStatus: lastactive.serviceStatus },
        { $set: { serviceStatus: 'Complate' } },
        { new: true }
      );
    }
    const ActiveToken = await dailytoken.findOne({ clinic: id, serviceStatus: 'Active' });
    return ActiveToken.tokenNo;
  }
  const findActiveuser = await dailytoken.findOne({ clinic: id, serviceStatus: 'Active' });
  // Active token are found or not.
  if (!(findActiveuser == null)) {
    const updateActiveuser = await dailytoken.findOneAndUpdate(
      { clinic: id, serviceStatus: findActiveuser.serviceStatus },
      { $set: { serviceStatus: 'Complate' } }
    );
    const tokennolast = await dailytoken.find({
      clinic: id,
      $or: [{ serviceStatus: 'Pending' }, { serviceStatus: 'Active' }],
    });
    // pending and Active token are found or not.
    if (!tokennolast[0]) {
      throw new ApiError(httpStatus.NOT_FOUND, 'All token are Complate No pending token');
    }
    return findActiveuser.tokenNo;
  }
};

// PUT: Cancel Token by user.
const cencelcurrenttoken = async (id, tokenno) => {
  const status = await dailytoken.findOne({ clinic: id, tokenNo: tokenno });
  const update = await dailytoken.updateOne(
    { clinic: id, tokenNo: tokenno, serviceStatus: status.serviceStatus },
    { $set: { serviceStatus: 'Cancelled' } }
  );
};

// All Modules are Exports from here 👇
module.exports = {
  bookingtoken,
  getTokenData,
  findbytoken,
  findbyclinicid,
  findbyuserid,
  changeTokenStatus,
  cencelcurrenttoken,
};
