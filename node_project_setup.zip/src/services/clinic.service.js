const httpStatus = require('http-status');
const { clinic, service } = require('../models');
const ApiError = require('../utils/ApiError');
const Categories = require('../models/categories.model');

// create clinic collection
const createclinics = async (payload) => {
  return clinic.create(payload);
};

// find by clinic id
const findbyid = async (id) => {
  return clinic.findById(id);
};

// delete clinic in clinic collection
const deleteclinic = async ({id}) => {
  return clinic.findByIdAndUpdate(
    { _id: id },
    {
      $set: {
        deletedAt: new Date(),
      },
    }
  );
};

// find clinic data in clinic collecton
const finddata = async () => {
  return clinic.find({});
};

// get clinic data in clinic collection
const getdata = async (id) => {
  return clinic.findOne(id).populate('category , service');
};

// update clinic data in clinic collection
const updateClinic = async (id, data) => {
  return clinic.updateOne(
    { _id: id },
    {
      $set: {
        ...data,
      },
    },
    {
      new: true,
    }
  );
};

// get clinic in clinic collection
const getClinic = async (filter, options) => {
  return clinic.paginate(filter, options);
};

// find token in clinic token
const findtoken = async (payload) => {
  return clinic.find({ payload });
};

// Checking
const check = async (payload) => {
  // Check Category are found or not in 'category' collection.
  const checkCategories = await Categories.findById(payload.category);
  if (!checkCategories) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Categories are not Found');
  }

  // Check Mobile Number Are alredy Use or Not.
  const checkmobileno = await clinic.findOne({ doctorMobileNo: payload.doctorMobileNo });
  if (checkmobileno) {
    throw new ApiError(httpStatus.ALREADY_REPORTED, 'Mobile Number are already use');
  }

  // Check Email Id Are Already Use or Not.
  const chakemail = await clinic.findOne({ email: payload.email });
  if (chakemail) {
    throw new ApiError(httpStatus.ALREADY_REPORTED, 'Email Id are already use');
  }
};

// All Modules are Exports from here 👇
module.exports = {
  createclinics,
  findbyid,
  deleteclinic,
  finddata,
  getdata,
  updateClinic,
  getClinic,
  findtoken,
  check,
};
