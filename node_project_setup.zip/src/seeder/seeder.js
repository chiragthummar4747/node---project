const { cityList } = require('./IndianCity');
const cityModel = require('../models/city.model');

const allCityList = async (req, res) => {
  cityList.forEach((city) => {
    cityModel.create({ city_name: city, country: '6299a8ef36636252803b450c' }); // Add here your database's country ID.
  });
};

module.exports = { allCityList };
