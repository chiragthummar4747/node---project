const categories = {
  Urology: 'UROLOGY',
  General_Physicians: 'GENERAL PHYSICIANS',
  Pediatricians: 'PEDIATRICIANS',
  Surgeon: 'SURGEON',
  Cardiologist: 'CARDIOLOGIST',
  Neurology: 'NEUROLOGY',
  Dentist: 'DENTIST',
  Dermatologists: 'DERMATOLOGISTS',
  Gynecolgist: 'GYNECOLOGIST',
  ENT_specialist: 'ENT SPECIALIST',
};

const categories_name = Object.values(categories);
module.exports = categories_name;
