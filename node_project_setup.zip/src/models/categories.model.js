const mongoose = require('mongoose');
const { toJSON, paginate } = require('./plugins');
const clinicuser = require('../config/clinic');
const categoriesSchema = mongoose.Schema(
  {
    categories_name: {
      type: String,
      trim: true,
      unique: true,
      uppercase: true,
      enum: clinicuser,
      required: true,
    },
    categoriesImage: {
      type: String,
      required: true,
    },
    isActive: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

categoriesSchema.plugin(toJSON);
categoriesSchema.plugin(paginate);


const categories = mongoose.model('category', categoriesSchema);

module.exports = categories;
