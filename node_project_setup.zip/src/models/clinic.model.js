const mongoose = require('mongoose');
const { toJSON, paginate } = require('./plugins');
const validator = require('validator');
const bcrypt = require('bcryptjs');
const categories = require('./categories.model');

const clinicSchema = mongoose.Schema(
  {
    email: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true,
      validate(value) {
        if (!validator.isEmail(value)) {
          throw new Error('Invalid email');
        }
      },
    },
    password: {
      type: String,
      required: true,
      trim: true,
      minlength: 8,
      validate(value) {
        if (!value.match(/\d/) || !value.match(/[a-zA-Z]/)) {
          throw new Error('Password must contain at least one letter and one number');
        }
      },
      private: true,
    },
    clinicName: {
      type: String,
      uppercase: true,
      trim: true,
      required: true,
    },
    doctorName: {
      type: String,
      trim: true,
      required: true,
    },
    doctorExperience: {
      type: String,
      trim: true,
      required: true,
    },
    doctorMobileNo: {
      type: Number,
      trim: true,
      unique: true,
      required: true,
    },
    clinicAdress: {
      type: String,
      trim: true,
      required: true,
    },
    clinicReview: {
      type: Number,
      trim: true,
    },
    clinicDescription: {
      type: String,
      trim: true,
    },
    openingHours: {
      type: Array,
      trim: true,
    },
    category: {
      type: mongoose.Types.ObjectId,
      ref: 'category',
    },
    service: {
      type: [mongoose.Types.ObjectId],
      ref: 'service',
    },
    clinicImage: {
      type: String,
      // required: true,
    },
    dailyToken: {
      type: Number,
      required: true,
      min: 1,
      max: 50,
    },
    isActive: {
      type: Boolean,
      default: false,
    },
    deletedAt: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

clinicSchema.plugin(toJSON);
clinicSchema.plugin(paginate);

clinicSchema.pre('save', async function (next) {
  const user = this;
  if (user.isModified('password')) {
    user.password = await bcrypt.hash(user.password, 8);
  }
  next();
});

clinicSchema.path('doctorMobileNo').validate(async (doctorMobileNo) => {
  const mobileNoCount = await mongoose.models.clinic.countDocuments({ doctorMobileNo });
  return !mobileNoCount;
}, 'Mobile Number are already Used, Enter another Mobile No');

const clinic = mongoose.model('clinic', clinicSchema);
module.exports = clinic;
