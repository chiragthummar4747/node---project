const { string } = require('joi');
const mongoose = require('mongoose');
const { toJSON, paginate } = require('./plugins');

const dailytokenSchema = mongoose.Schema(
  {
    clinic: {
      type: mongoose.Types.ObjectId,
      ref: 'clinic',
    },
    user: {
      type: mongoose.Types.ObjectId,
      ref: 'User',
    },
    tokenNo: {
      type: Number,
    },
    tokenId: {
      type: String,
      trim: true,
    },
    isActive: {
      type: Boolean,
      default: false,
    },
    serviceStatus: {
      type: String,
      default: 'Pending',
      trim: true,
    },
  },
  {
    timestamps: true,
  }
);

dailytokenSchema.plugin(toJSON);
dailytokenSchema.plugin(paginate);

const dailytoken = mongoose.model('dailybookingtoken', dailytokenSchema);

module.exports = dailytoken;
