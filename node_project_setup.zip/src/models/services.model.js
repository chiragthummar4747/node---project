const mongoose = require('mongoose');
const { toJSON, paginate } = require('./plugins');
const serviceSchema = mongoose.Schema(
  {
    services: {
      type: String,
      uppercase: true,
      trim: true,
    },
  },
  {
    timestamps: true,
  }
);

serviceSchema.plugin(toJSON);
serviceSchema.plugin(paginate);

const service = mongoose.model('service', serviceSchema);

module.exports = service;
