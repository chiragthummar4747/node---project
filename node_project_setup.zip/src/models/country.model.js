const mongoose = require('mongoose');
const { toJSON, paginate } = require('./plugins');

const countrySchema = mongoose.Schema(
  {
    country_name: {
      type: String,
      uppercase: true,
      unique: true,
      trim: true,
      required: true,
    },
    country_code: {
      type: String,
      unique: true,
      trim: true,
      required: true,
    },
    country_currency: {
      type: String,
      uppercase: true,
      trim: true,
      required: true,
    },
    country_ISO: {
      type: String,
      uppercase: true,
      unique: true,
      trim: true,
      required: true,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

countrySchema.plugin(toJSON);
countrySchema.plugin(paginate);

const country = mongoose.model('country', countrySchema);

module.exports = country;
