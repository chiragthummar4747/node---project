const mongoose = require('mongoose')
const { toJSON, paginate } = require('./plugins')
const serviceFeedbackSchema = mongoose.Schema(
    {
        clinic: {
            type: mongoose.Types.ObjectId,
            ref: 'clinic',
        },
        user: {
            type: mongoose.Types.ObjectId,
            ref: 'User'
        },
        service:{
            type:mongoose.Types.ObjectId,
            ref:'service'
        },
        rate: {
            type: Number
        },
        description:{
            type:String,
        },
        isActive: {
            type: Boolean,
            default: false,
        },
        tokenId: {
            type: String,
            trim: true,
        },
    },
    {
        timestamps: true,
    }
);

serviceFeedbackSchema.plugin(toJSON);
serviceFeedbackSchema.plugin(paginate)

const feedback = mongoose.model('servicefeedback',serviceFeedbackSchema)
module.exports = feedback