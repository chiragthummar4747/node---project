const joi = require('joi');
const { objectId } = require('./custom.validation');

// POST: Add new city in database
const createCity = {
  body: joi.object().keys({
    city_name: joi.string().required(),
    country: joi.string().required().custom(objectId),
  }),
};

// GET: Show all city data
const getCity = {
  query: joi.object().keys({
    city_name: joi.string().allow(''),
    sortBy: joi.string(),
    limit: joi.number().integer(),
    page: joi.number().integer(),
  }),
};

// GET: show city data by ObjectID
const getCityById = {
  param: joi.object().keys({
    id: joi.string().custom(objectId),
  }),
};

// GET: Show city data by Country
const getCityByCountry = {
  param: joi.object().keys({
    id: joi.string().custom(objectId),
  }),
  query: joi.object().keys({
    city_name: joi.string(),
    sortBy: joi.string(),
    limit: joi.number().integer(),
    page: joi.number().integer(),
  }),
};

// PUT: Update city data by ObjectID
const updateCity = {
  param: joi.object().keys({
    id: joi.string().custom(objectId),
  }),
  body: joi.object().keys({
    city_name: joi.string(),
    country: joi.string().custom(objectId),
  }),
};

// DELETE: Delete City data by ObjectID
const deleteCity = {
  param: joi.object().keys({
    id: joi.string().custom(objectId),
  }),
};

// All Modules are Exports from here 👇
module.exports = {
  createCity,
  getCityById,
  getCity,
  getCityByCountry,
  updateCity,
  deleteCity,
};
