const joi = require('joi');
const { objectId } = require('./custom.validation');

// POST: Booking Token
const bookingtoken = {
  body: joi.object().keys({
    clinic: joi.string().custom(objectId).required(),
    user: joi.string().custom(objectId).required(),
    date: joi.string(),
  }),
};

// GET: Show All Token Data from database
const getTokenData = {
  query: joi.object().keys({
    date: joi.string().allow(''),
    sortBy: joi.string(),
    limit: joi.number().integer(),
    page: joi.number().integer(),
  }),
};

// PUT: Which token are now current Token
const changeTokenStatus = {
  param: joi.object().keys({
    clinicId: joi.string().custom(objectId),
  }),
  body: joi.object().keys({
    date: joi.string(),
  }),
};

// PUT: Cancel Token by user.
const cancelToken = {
  param: joi.object().keys({
    clinicId: joi.string().custom(objectId),
  }),
  body: joi.object().keys({
    date: joi.string(),
    tokenNo: joi.number(),
  }),
};

// All Modules are Exports from here 👇
module.exports = {
  bookingtoken,
  getTokenData,
  changeTokenStatus,
  cancelToken,
};
