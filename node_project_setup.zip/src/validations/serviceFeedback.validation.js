const joi = require('joi')
const { objectId } = require('./custom.validation')

// create feedback 
const createservicefeedback = {
    param: joi.object().keys({
        id: joi.string().custom(objectId)
    }),
    body: joi.object().keys({
        user: joi.string().custom(objectId),
        service: joi.string().custom(objectId),
        rate: joi.number(),
        description: joi.string(),
        tokenId: joi.string()
    })
}

// update feedback
const updatefeedback = {
    param: joi.object().keys({
        id: joi.string().custom(objectId)
    }),
    body: joi.object().keys({
        service: joi.string().custom(objectId),
        rate: joi.number(),
        description: joi.string(),
        tokenId: joi.string()
    })
}

// delete feedback
const deletefeedback = {
    param:joi.object().keys({
        id:joi.string().custom(objectId)
    })
}

// module are export
module.exports = {
    createservicefeedback,
    updatefeedback,
    deletefeedback
}