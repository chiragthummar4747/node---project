const joi = require('joi');
const { password } = require('./custom.validation');
const { objectId } = require('./custom.validation');

// POST: Create a clinic
const createclinic = {
  body: joi.object().keys({
    email: joi.string().required(),
    password: joi.string().required().custom(password),
    clinicName: joi.string().required(),
    doctorName: joi.string().required(),
    doctorExperience: joi.string().required(),
    doctorMobileNo: joi.number().required(),
    clinicAdress: joi.string().required(),
    openingHours: joi.array().required(),
    clinicDescription: joi.string(),
    clinicReview: joi.number(),
    category: joi.string().custom(objectId).required(),
    service: joi.array().required(),
    clinicImage: joi.string(),
    dailyToken: joi.number().required(),
  }),
};

// GET: show all clinic data
const getAllclinic = {
  query: joi.object().keys({
    clinicName: joi.string().allow(''),
    sortBy: joi.string(),
    limit: joi.number().integer(),
    page: joi.number().integer(),
  }),
};

// GET: Show clinic data by ObjectID
const getclinicuser = {
  param: joi.object().keys({
    id: joi.string().required(),
  }),
};

// PUT: Update clinic data by ObjectID
const updateclinic = {
  param: joi.object().keys({
    id: joi.string().required(),
  }),
  body: joi.object().keys({
    clinicName: joi.string(),
    doctorName: joi.string(),
    doctorExperience: joi.string(),
    doctorMobileNo: joi.number(),
    clinicAdress: joi.string(),
    clinicReview: joi.number(),
    clinicDescription: joi.string(),
    openingHours: joi.array(),
    category: joi.string().custom(objectId),
    service: joi.array().custom(objectId),
    clinicImage: joi.string(),
    dailyToken: joi.number(),
  }),
};

// GET: Show clinic Token
const getclinictoken = {
  param: joi.object().keys({
    id: joi.string().required(),
  }),
};

// GET: show clinic by Location
const getlocationwiseclinic = {
  query: joi.object().keys({
    clinicAdress: joi.string().allow(''),
    sortBy: joi.string(),
    limit: joi.number().integer(),
    page: joi.number().integer(),
  }),
};

// DELETE: Delete clinic by ObjectID
const deleteclinic = {
  param: joi.object().keys({
    id: joi.string().required(),
  }),
};

// All Modules are Exports from here 👇
module.exports = {
  createclinic,
  getAllclinic,
  getclinicuser,
  updateclinic,
  getclinictoken,
  getlocationwiseclinic,
  deleteclinic,
};
