const Joi = require('joi');
const { password, objectId } = require('./custom.validation');

// POST: Register user
const register = {
  body: Joi.object().keys({
    mobile_no: Joi.number().required(),
    location: Joi.object().required(),
  }),
};

// POST: Login user
const login = {
  body: Joi.object().keys({
    email: Joi.string().required(),
    password: Joi.string().required(),
  }),
};

const logout = {
  body: Joi.object().keys({
    refreshToken: Joi.string().required(),
  }),
};

const refreshTokens = {
  body: Joi.object().keys({
    refreshToken: Joi.string().required(),
  }),
};

const forgotPassword = {
  body: Joi.object().keys({
    email: Joi.string().email().required(),
  }),
};

const resetPassword = {
  query: Joi.object().keys({
    token: Joi.string().required(),
  }),
  body: Joi.object().keys({
    password: Joi.string().required().custom(password),
  }),
};

// POST: Verify OTP
const verifyotp = {
  query: Joi.object().keys({
    otp: Joi.string().required(),
  }),
};

// PUT: Update user details by ObjectID
const updateuser = {
  param: Joi.object().keys({
    id: Joi.string().required(objectId),
  }),
  body: Joi.object().keys({
    first_name: Joi.string().required(),
    last_name: Joi.string().required(),
    gender: Joi.string().required(),
    address: Joi.string().required(),
    age: Joi.number().required(),
    userImage: Joi.string(),
  }),
};

// All Modules are Exports from here 👇
module.exports = {
  register,
  login,
  logout,
  refreshTokens,
  forgotPassword,
  resetPassword,
  verifyotp,
  updateuser,
};
