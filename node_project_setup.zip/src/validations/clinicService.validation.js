const joi = require('joi');
const { objectId } = require('./custom.validation');

// POST: create Clinic Service
const createClinicService = {
  body: joi.object().keys({
    clinic: joi.string().required().custom(objectId),
    service: joi.array().required(),
  }),
};

// GET: Show All clinic Service
const getClinicService = {
  query: joi.object().keys({
    clinic: joi.string().allow(''),
    sortBy: joi.string(),
    limit: joi.number().integer(),
    page: joi.number().integer(),
  }),
};

// All Modules are Exports from here 👇
module.exports = {
  createClinicService,
  getClinicService,
};
