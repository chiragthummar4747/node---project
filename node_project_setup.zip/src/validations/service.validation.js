const joi = require('joi');

// POST: Create a Services
const createservices = {
  body: joi.object().keys({
    services: joi.string().required(),
  }),
};

// All Modules are Exports from here 👇
module.exports = {
  createservices,
};
