const joi = require('joi');
const { objectId } = require('./custom.validation');

// POST: Create Category
const createCategories = {
  body: joi.object().keys({
    categories_name: joi.string(),
    categoriesImage: joi.string(),
  }),
};

// GET: find all category from here
const getCategories = {
  query: joi.object().keys({
    categories_name: joi.string().allow(''),
    sortBy: joi.string(),
    limit: joi.number().integer(),
    page: joi.number().integer(),
  }),
};

// GET: find category by ObjectID
const getCategoriesById = {
  param: joi.object().keys({
    id: joi.string().custom(objectId),
  }),
};

// PUT: Update Category by ObjectID
const updateCategories = {
  param: joi.object().keys({
    id: joi.string().custom(objectId),
  }),
  body: joi.object().keys({
    categories_name: joi.string(),
    categoriesImage: joi.string(),
  }),
};

// DELETE: Delete Category by ObjectID
const deleteCategories = {
  param: joi.object().keys({
    id: joi.string().custom(objectId),
  }),
};

// All Modules are Exports from here 👇
module.exports = {
  createCategories,
  getCategories,
  getCategoriesById,
  updateCategories,
  deleteCategories,
};
