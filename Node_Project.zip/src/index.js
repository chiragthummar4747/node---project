const mongoose = require('mongoose');
const http = require('http');
const app = require('./app');
const config = require('./config/config');
const logger = require('./config/logger');

app.set('port', config.port);
const server = http.createServer(app);

mongoose.connect(config.mongoose.url, config.mongoose.options).then(() => {
  logger.info('Connected to MongoDB');
});
mongoose.set('useFindAndModify', false);
const io = require('socket.io')(server, {
  cors: {
    origin: true,
    credentials: true,
  },
  allowEIO3: true,
});

// socket.io.js  file require here
const { socketIO } = require('./services/socket.io');
socketIO(io);

// Server listen to port
server.listen(config.port, () => {
  logger.info(`Server listen port number: ${config.port}`);
});

const exitHandler = () => {
  if (server) {
    server.close(() => {
      logger.info('Server closed');
      process.exit(1);
    });
    1;
  } else {
    process.exit(1);
  }
};

const unexpectedErrorHandler = (error) => {
  logger.error(error);
  exitHandler();
};

process.on('uncaughtException', unexpectedErrorHandler);
process.on('unhandledRejection', unexpectedErrorHandler);

process.on('SIGTERM', () => {
  logger.info('SIGTERM received');
  if (server) {
    server.close();
  }
});
