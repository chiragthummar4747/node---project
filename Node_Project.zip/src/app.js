const express = require('express');
const helmet = require('helmet');
const xss = require('xss-clean');
const mongoSanitize = require('express-mongo-sanitize');
const compression = require('compression');
const cors = require('cors');
const passport = require('passport');
const httpStatus = require('http-status');
const config = require('./config/config');
const morgan = require('./config/morgan');
const { jwtStrategy } = require('./config/passport');
const { authLimiter } = require('./middlewares/rateLimiter');
const routes = require('./routes/v1');
const { errorConverter, errorHandler } = require('./middlewares/error');
const ApiError = require('./utils/ApiError');
const path = require('path');
const winston = require('winston');
const { format } = winston
const expressWinston = require('express-winston')
const app = express();

// set logger
expressWinston.requestWhitelist.push('body');
app.use(
  expressWinston.logger({
    transports: [
      new winston.transports.Console({
        format: format.combine(
          format.colorize({
            all: true,
          }),
        ),
      }),
      new winston.transports.File({
        filename: `./logs/request_log/logfile_${new Date().toISOString().split('T')[0]
          }.log`,
        level: 'silly',
      }),
    ],
    format: winston.format.combine(
      winston.format.simple(),
      winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
      winston.format.printf((info) => {
        let print = `${info.timestamp} [${info.meta.req.headers.origin ||
          info.meta.req.headers.host
          }] ${info.level} : ${info.message}`;
        let decoded;
        if (info.meta.req.headers['x-access-token']) {
          decoded = jwt.verify(
            info.meta.req.headers['x-access-token'],
            process.env.JWT_SECRET,
          );
          print += ` [userId : ${decoded.id}]`;
        }

        if (info.meta.req.body) {
          print += ` -- ${JSON.stringify(info.meta.req.body)}`;
        }

        return print;
      }),
    ),
    requestWhitelist: ['body', 'headers'],
    bodyWhitelist: ['FirstName', 'LastName', 'personId'],
    meta: true,
    expressFormat: true,
    ignoreRoute: (req, res) => req.url === '/',
  }),
);

if (config.env !== 'test') {
  app.use(morgan.successHandler);
  app.use(morgan.errorHandler);
}

// set security HTTP headers
app.use(helmet());

// parse json request body
app.use(express.json());

// parse urlencoded request body
app.use(express.urlencoded({ extended: true }));

// sanitize request data
app.use(xss());
app.use(mongoSanitize());


// gzip compression
app.use(compression());

// enable cors
app.use(cors());
app.options('*', cors());

// jwt authentication
app.use(passport.initialize());
passport.use('jwt', jwtStrategy);

// limit repeated failed requests to auth endpoints
if (config.env === 'production') {
  app.use('/v1/auth', authLimiter);
}

// v1 api routes
app.use('/v1', routes);
app.use(express.static(path.join(__dirname, '..', 'uploads')))

// send back a 404 error for any unknown api request
app.use((req, res, next) => {
  next(new ApiError(httpStatus.NOT_FOUND, 'Not found'));
});

// convert error to ApiError, if needed
app.use(errorConverter);

// handle error
app.use(errorHandler);

// image upload
// app.use('/clinic', express.static('uploads'));

module.exports = app;
