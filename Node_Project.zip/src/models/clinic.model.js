const mongoose = require('mongoose');
const { toJSON, paginate } = require('./plugins');

const clinicSchema = mongoose.Schema(
  {
    clinicName: {
      type: String,
      trim: true,
    },
    clinicAddress: {
      type: String,
      trim: true,
    },
    clinicDescription: {
      type: String,
      trim: true,
    },
    openingHours: {
      type: Array,
      trim: true,
    },
    doctor: {
      type: mongoose.Types.ObjectId,
      ref: 'doctor',
    },
    category: {
      type: mongoose.Types.ObjectId,
      ref: 'category',
    },
    service: {
      type: [mongoose.Types.ObjectId],
      ref: 'service',
    },
    location: {
      type: {
        type: String,
        default: 'Point',
      },
      coordinates: [Number],
    },
    clinicImage: {
      type: String,
    },
    dailyToken: {
      type: Number,
      min: 1,
      max: 50,
    },
    isActive: {
      type: Boolean,
      default: false,
    },
    deletedAt: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

clinicSchema.plugin(toJSON);
clinicSchema.plugin(paginate);

// We create the index for `$geoNear`
clinicSchema.index({
  location: '2dsphere',
});

// Image url create and Show image (for Multiple data)
clinicSchema.post('paginate', async (data, next) => {
  data.results.forEach((element) => {
    if (element.clinicImage) {
      element.clinicImage = `${process.env.IMAGE_URL}${element.clinicImage}`;
    } else {
      element.userImage = `${process.env.IMAGE_URL}default/clinic.jpeg`;
    }
  });
  next();
});

clinicSchema.post('aggregate', async (data, next) => {
  data[0].results.forEach((element) => {
    if (element.clinicImage) {
      element.clinicImage = `${process.env.IMAGE_URL}${element.clinicImage}`;
    } else {
      element.clinicImage = `${process.env.IMAGE_URL}default/clinic.jpeg`;
    }
  });
  next();
});

clinicSchema.post('findOne', async (data, next) => {
  if(data){
    if (data.clinicImage) {
      data.clinicImage = `${process.env.IMAGE_URL}${data.clinicImage}`;
    } else {
      data.clinicImage = `${process.env.IMAGE_URL}default/clinic.jpeg`;
    }
  }
  next();
});

const clinic = mongoose.model('clinic', clinicSchema);
module.exports = clinic;
