const mongoose = require('mongoose');
const { toJSON, paginate } = require('./plugins');
const Category = require('../config/category');
const categoriesSchema = mongoose.Schema(
  {
    categories_name: {
      type: String,
      trim: true,
      unique: true,
      uppercase: true,
      enum: Category,
      required: true,
    },
    isActive: {
      type: Boolean,
      default: false,
    },
    deletedAt: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

categoriesSchema.plugin(toJSON);
categoriesSchema.plugin(paginate);

const categories = mongoose.model('category', categoriesSchema);
module.exports = categories;
