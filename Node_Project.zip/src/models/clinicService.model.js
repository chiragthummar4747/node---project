const mongoose = require('mongoose');
const { toJSON, paginate } = require('./plugins');

const clinicServiceSchema = mongoose.Schema(
  {
    clinic: {
      type: mongoose.Types.ObjectId,
      ref: 'clinic',
    },
    service: {
      type: [mongoose.Types.ObjectId],
      ref: 'service',
    },
  },
  {
    timestamps: true,
  }
);

clinicServiceSchema.plugin(toJSON);
clinicServiceSchema.plugin(paginate);

const clinicService = mongoose.model('clinic_service', clinicServiceSchema);

module.exports = clinicService;
