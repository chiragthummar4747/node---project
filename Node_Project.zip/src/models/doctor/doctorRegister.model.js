const mongoose = require('mongoose');
const validator = require('validator');
const bcrypt = require('bcryptjs');
const { toJSON, paginate } = require('../plugins');

const doctorSchema = mongoose.Schema(
  {
    email: {
      type: String,
      lowercase: true,
      unique: true,
      trim: true,
      validate(value) {
        if (!validator.isEmail(value)) {
          throw new Error('Invalid Email, Please Enter valid Email!');
        }
      },
    },
    password: {
      type: String,
      trim: true,
      minlength: 8,
      private: true,
    },
    role: {
      type: mongoose.Types.ObjectId,
      ref: 'role',
    },
    first_name: {
      type: String,
      trim: true,
    },
    last_name: {
      type: String,
      trim: true,
    },
    mobile_no: {
      type: Number,
      unique: true,
      trim: true,
    },
    doctorImage: {
      type: String,
      trim: true,
    },
    address: {
      type: String,
      trim: true,
    },
    age: {
      type: Number,
    },
    isActive: {
      type: Boolean,
      default: false,
    },
    isProfileComplate: {
      type: Boolean,
      default: false,
    },
    isEmailVerified: {
      type: Boolean,
      default: false,
    },
    deletedAt: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to JSON
doctorSchema.plugin(toJSON);
doctorSchema.plugin(paginate);

doctorSchema.methods.isPasswordMatch = async function (password) {
  const user = this;
  return bcrypt.compare(password, user.password);
};

doctorSchema.pre('save', async function (next) {
  const user = this;
  if (user.isModified('password')) {
    user.password = await bcrypt.hash(user.password, 8);
  }
  next();
});

// Image url create and Show image (for Multiple data)
doctorSchema.post('find', async (data, next) => {
  data.forEach((element) => {
    if (element.doctorImage) {
      element.doctorImage = `${process.env.IMAGE_URL}${element.doctorImage}`;
    } else {
      element.doctorImage = `${process.env.IMAGE_URL}default/profile.png`;
    }
  });
  next();
});

// Image url create and Show image (for Multiple data)
doctorSchema.post('findOneAndUpdate', async (data, next) => {
  if (data.doctorImage) {
    data.doctorImage = `${process.env.IMAGE_URL}${data.doctorImage}`;
  } else {
    data.doctorImage = `${process.env.IMAGE_URL}default/profile.png`;
  }
  next();
});

// Image url create and Show image (for Multiple data)
doctorSchema.post('aggregate', async (data, next) => {
  for (const iterator of data) {
    if (iterator.doctorImage) {
      iterator.doctorImage = `${process.env.IMAGE_URL}${iterator.doctorImage}`;
    } else {
      iterator.doctorImage = `${process.env.IMAGE_URL}default/profile.png`;
    }
  }
  next();
});

const doctor = mongoose.model('doctor', doctorSchema);

module.exports = doctor;
