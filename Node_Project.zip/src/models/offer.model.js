const mongoose = require('mongoose');
const { toJSON, paginate } = require('./plugins');

const offerSchema = mongoose.Schema(
  {
    title: {
      type: String,
    },
    description: {
      type: String
    },
    offerImage: {
      type: String
    },
    clinicId: {
      type: mongoose.Types.ObjectId,
      ref: 'clinic',
    },
    isActive: {
      type: Boolean,
      default: true
    },
    deletedAt:{
      type:Date,
      default:null
    }
  },
  {
    timestamps: true,
  }
);

// Image url create and Show image (for Multiple data)
offerSchema.post('paginate', async (data, next) => {
  data.results.forEach((element) => {
    if (element.offerImage) {
      element.offerImage = `${process.env.IMAGE_URL}${element.offerImage}`;
    } 
  });
  next();
});

offerSchema.post('findOne', async (data, next) => {
    if (data.offerImage) {
      data.offerImage = `${process.env.IMAGE_URL}${data.offerImage}`;
    } 
  next();
});

offerSchema.plugin(toJSON);
offerSchema.plugin(paginate);

const Offer = mongoose.model('offer', offerSchema);
module.exports = Offer;
