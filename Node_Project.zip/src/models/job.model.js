const mongoose = require('mongoose');
const { toJSON, paginate } = require('./plugins');

const jobSchema = mongoose.Schema(
  {
    title: {
      type: String,
    },
    description: {
      type: String
    },
    jobImage: {
      type: String
    },
    clinicId: {
      type: mongoose.Types.ObjectId,
      ref: 'clinic',
    },
    isActive: {
      type: Boolean,
      default: true
    },
    deletedAt:{
      type:Date,
      default:null
    }
  },
  {
    timestamps: true,
  }
);

// Image url create and Show image (for Multiple data)
jobSchema.post('paginate', async (data, next) => {
  
  data.results.forEach((element) => {
    if (element.jobImage) {
      element.jobImage = `${process.env.IMAGE_URL}${element.jobImage}`;
    } 
  });
  next();
});

jobSchema.post('findOne', async (data, next) => {
    if (data.jobImage) {
      data.jobImage = `${process.env.IMAGE_URL}${data.jobImage}`;
    } 
  next();
});

jobSchema.plugin(toJSON);
jobSchema.plugin(paginate);

const Job = mongoose.model('job', jobSchema);
module.exports = Job;
