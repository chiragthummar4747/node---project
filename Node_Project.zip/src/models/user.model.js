const mongoose = require('mongoose');
const validator = require('validator');
const bcrypt = require('bcryptjs');
const { toJSON, paginate } = require('./plugins');
const { roles } = require('../config/roles');

const userSchema = mongoose.Schema(
  {
    mobile_no: {
      type: Number,
      required: true,
      minlength: 10,
      maxlength: 10,
      trim: true,
    },
    first_name: {
      type: String,
      trim: true,
    },
    last_name: {
      type: String,
      trim: true,
    },
    gender: {
      type: String,
      trim: true,
    },
    address: {
      type: String,
      trim: true,
    },
    age: {
      type: Number,
    },
    userImage: {
      type: String,
      trim: true,
    },
    role: {
      type: mongoose.Types.ObjectId,
      ref: 'role',
    },
    isActive: {
      type: Boolean,
      default: false,
    },
    location: {
      type: {
        type: String,
        default: 'Point',
      },
      coordinates: [],
    },
    isProfileComplate: {
      type: Boolean,
      default: false,
    },
    deletedAt: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
userSchema.plugin(toJSON);
userSchema.plugin(paginate);

/**
 * Check if email is taken
 * @param {string} email - The user's email
 * @param {ObjectId} [excludeUserId] - The id of the user to be excluded
 * @returns {Promise<boolean>}
 */
userSchema.statics.isEmailTaken = async function (email, excludeUserId) {
  const user = await this.findOne({ email, _id: { $ne: excludeUserId } });
  return !!user;
};

/**
 * Check if password matches the user's password
 * @param {string} password
 * @returns {Promise<boolean>}
 */
userSchema.methods.isPasswordMatch = async function (password) {
  const user = this;
  return bcrypt.compare(password, user.password);
};

userSchema.pre('save', async function (next) {
  const user = this;
  if (user.isModified('password')) {
    user.password = await bcrypt.hash(user.password, 8);
  }
  next();
});

// Image url create and Show image (for Multiple data)
userSchema.post('find', async (data, next) => {
  data.forEach((element) => {
    if (element.userImage) {
      element.userImage = `${process.env.IMAGE_URL}${element.userImage}`;
    } else {
      element.userImage = `${process.env.IMAGE_URL}default/profile.png`;
    }
  });
  next();
});

/**
 * Image url create and Show image (for Multiple data)
 */
userSchema.post('paginate', async (data, next) => {
  data.results.forEach((element) => {
    if (element.userImage) {
      element.userImage = `${process.env.IMAGE_URL}${element.userImage}`;
    } else {
      element.userImage = `${process.env.IMAGE_URL}default/profile.png`;
    }
  });
  next();
});

/**
 * @typedef User
 */
const User = mongoose.model('User', userSchema);

module.exports = User;
