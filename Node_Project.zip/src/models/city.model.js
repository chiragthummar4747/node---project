const mongoose = require('mongoose');
const { toJSON, paginate } = require('./plugins');

const citySchema = mongoose.Schema(
  {
    city_name: {
      type: String,
      trim: true,
      required: true,
    },
    country: {
      type: mongoose.SchemaTypes.ObjectId,
      ref: 'country',
    },
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

citySchema.plugin(toJSON);
citySchema.plugin(paginate);

const city = mongoose.model('city', citySchema);
module.exports = city;
