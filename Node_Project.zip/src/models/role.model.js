const mongoose = require('mongoose');
const { toJSON, paginate } = require('./plugins');
const { roles } = require('../config/roles');

const roleSchema = mongoose.Schema(
  {
    role: {
      type: String,
      enum: roles,
      required: true,
    },
    isActive: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

roleSchema.plugin(toJSON);
roleSchema.plugin(paginate);

const role = mongoose.model('role', roleSchema);
module.exports = role;
