const { role, dailytoken, clinic, doctor, User } = require('../../models');
const emailService = require('../email.service');
const moment = require('moment');

// POST: Doctor Register API
const doctorRegister = async (email) => {
  const sendPassword = await generatePassword(15);
  const roles = await role.findOne({ role: 'Doctor' });
  await emailService.sendRegisterPasswordEmail(email, sendPassword);
  return doctor.create({ email, password: sendPassword, role: roles.id });
};

// POST: Doctor login API
const doctorLogin = async (email) =>
  doctor
    .findOneAndUpdate({ email: email }, { $set: { isActive: true, isEmailVerified: true } }, { new: true })
    .populate('role');

// Find Email in database
const getUserByEmail = async (email) => doctor.findOne({ email: email });

/**
 *
 * @param {Objectimport('mongoose').Id} id
 * @returns
 */
const getDoctorByObjectId = async (id) => doctor.findById(id);

/**
 *
 * @param {object} filterObj
 * @param {object} options
 * @returns
 */
const getAllDoctor = async (filterObj, options) => await doctor.paginate({ ...filterObj }, options);

// generate Password for send email.
const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789$!^-*/';
function generatePassword(length) {
  let result = ' ';
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}

/**
 *
 * @param {Objectimport('mongoose').Id} id
 * @param {Object} data
 * @returns
 */
const updateDoctorProfile = async (id, data) =>
  doctor.findOneAndUpdate({ _id: id }, { $set: { ...data, isProfileComplate: true } }, { new: true });

/**
 *
 * @returns {object} --> 1.totalClinics  2.totalTodayAppointments 3.totalPatient 4.completedService
 */
const totalClinicAndAppointment = async () => {
  const [totalClinics, totalTodayAppointments, totalPatient, completedService] = await Promise.all([
    clinic.count(),
    dailytoken
      .find({
        createdAt: {
          $gte: moment(moment().format('YYYY-MM-DD')).format('YYYY-MM-DD HH:mm:ss.SSS[Z]'),
          $lt: moment(moment(moment().add(1, 'days')).format('YYYY-MM-DD')).format('YYYY-MM-DD HH:mm:ss.SSS[Z]'),
        },
      })
      .count(),
    User.count(),
    dailytoken.find({ serviceStatus: "Complate" }).count()
  ]);
  return { totalClinics, totalTodayAppointments, totalPatient, completedService };
};

/**
 *
 * @param {Objectimport('mongoose').Id} roleId
 * @returns {string} --> role
 */
const getRole = async (roleId) => (await role.findOne({ _id: roleId })).role;

/**
 *
 * @param {*} doctorId
 * @returns {Object}
 */
const getDoctorProfile = async (doctorId) => {
  const doctorProfile = await doctor.aggregate([
    {
      $match: {
        _id: doctorId,
      },
    },
    {
      $lookup: {
        from: 'clinics',
        localField: '_id',
        foreignField: 'doctor',
        as: 'clinic_details',
      },
    },
    {
      $project: {
        password: 0,
      },
    },
  ]);
  return doctorProfile[0];
};

/**
 *
 * @param {array} query
 * @returns {Object}
 */
const getDoctorProfileById = async (query) => {
  const result = await doctor.aggregate(query);
  return result[0];
};

// All modules are exports from here
module.exports = {
  doctorRegister,
  doctorLogin,
  getUserByEmail,
  getAllDoctor,
  getDoctorByObjectId,
  updateDoctorProfile,
  totalClinicAndAppointment,
  getRole,
  getDoctorProfile,
  getDoctorProfileById,
};
