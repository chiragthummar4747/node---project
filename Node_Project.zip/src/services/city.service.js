const httpStatus = require('http-status');
const { City, Country } = require('../models');
const ApiError = require('../utils/ApiError');

// create city in 'city' collection.
const createCity = async (cityData) => (!await Country.findById({ _id: cityData.country })) ? (function () { throw new ApiError(httpStatus.NOT_FOUND, 'Country are not found, Please enter valid CountryID') })() : City.create(await alreadyExistCity(cityData));

// get all city and search city in 'city' collection.
const getCity = async (filter, options) => {
  options.populate = 'country'
  return City.paginate(filter, options)
}

// get city by City's ObjectID 'city' collection.
const getCityById = async (id) => City.findById(id).populate('country');

// get city By Country from 'city' collection.
const getCityByCountry = async (filter, options) => City.paginate(filter, options);

// UPDATE city in 'city' collection.
const updateCity = async (id, data) => (!await alreadyExistCity(data)) ? City.findOneAndUpdate({ _id: id }, { $set: { ...data } }, { new: true }) : 0;

// DELETE city in 'city' collection.
const deleteCity = async (id) => City.deleteOne({ _id: id });

// check city are already USED or NOT in 'city' collection.
const alreadyExistCity = async (citydata) => ((await City.find({ city_name: { $eq: citydata.city_name }, country: { $eq: citydata.country } })).length) ? (function () { throw new ApiError(httpStatus.ALREADY_REPORTED, 'City are already Used') })() : citydata;

// All Modules are Exports from here 👇
module.exports = {
  createCity,
  getCity,
  getCityById,
  getCityByCountry,
  updateCity,
  deleteCity,
  alreadyExistCity,
};
