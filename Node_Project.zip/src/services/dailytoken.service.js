const httpStatus = require('http-status');
const { dailytoken, clinic, User } = require('../models');
const ApiError = require('../utils/ApiError');
const moment = require('moment');

// create booking token in token collection
const bookingtoken = async ({ tokenId }, clinicid, user) => {
  const findByData = await dailytoken.findOne({
    $and: [
      {
        clinic: clinicid,
        user: user,
        createdAt: {
          $gte: moment(moment().format('YYYY-MM-DD')).format('YYYY-MM-DD HH:mm:ss.SSS[Z]'),
          $lt: moment(moment(moment().add(1, 'days')).format('YYYY-MM-DD')).format('YYYY-MM-DD HH:mm:ss.SSS[Z]'),
        },
      },
    ],
  });
  if (findByData) {
    return { tokenNo: findByData.tokenNo };
  } else {
    return BookingTokens();
  }

  // Book Token function
  async function BookingTokens() {
    const data = await clinic.findOne({ _id: clinicid });
    const totalToken = data.dailyToken;
    const findClinicRecord = await dailytoken.find({
      clinic: clinicid,
      createdAt: {
        $gte: moment(moment().format('YYYY-MM-DD')).format('YYYY-MM-DD HH:mm:ss.SSS[Z]'),
        $lt: moment(moment(moment().add(1, 'days')).format('YYYY-MM-DD')).format('YYYY-MM-DD HH:mm:ss.SSS[Z]'),
      },
    });
    if (findClinicRecord.length != 0) {
      if (totalToken > findClinicRecord.length) {
        const [lastrecord] = await dailytoken.find({ clinic: clinicid }).sort({ createdAt: -1 }).limit(1);
        const index = lastrecord.tokenNo + 1;
        return dailytoken.create({ clinic: clinicid, user, tokenId, tokenNo: index });
      } else {
        return 'Today All token are book on this clinic';
        // throw new ApiError(httpStatus.NOT_ACCEPTABLE, 'Today All token are book on this clinic');
      }
    } else {
      return dailytoken.create({ clinic: clinicid, user, tokenId, tokenNo: 1 });
    }
  }
};

// get booking token data in token collection
const getTokenData = async (filter, options) => {
  return dailytoken.paginate(filter, options);
};

// find token
const findbytoken = async (token) => {
  return dailytoken.find({ token });
};

// find clinic id in clinic collection
const findbyclinicid = async (id) => {
  return clinic.findById(id);
};

// find user id in user colletion
const findbyuserid = async (id) => {
  return User.findById(id);
};

// PUT: Show Current Token Api and Update serviceStatus
const changeTokenStatus = async (id) => {
  // pending token are found or not.
  const showtoken = await dailytoken.findOne({
    clinic: id,
    serviceStatus: 'Pending',
    createdAt: {
      $gte: moment(moment().format('YYYY-MM-DD')).format('YYYY-MM-DD HH:mm:ss.SSS[Z]'),
      $lt: moment(moment(moment().add(1, 'days')).format('YYYY-MM-DD')).format('YYYY-MM-DD HH:mm:ss.SSS[Z]'),
    },
  });
  if (showtoken) {
    const status = await dailytoken.findOneAndUpdate(
      { clinic: id, serviceStatus: showtoken.serviceStatus },
      { $set: { serviceStatus: 'Active' } }
    );
    const lastactive = await dailytoken.findOne({ clinic: id, serviceStatus: 'Active' }).skip(1);
    // Active token are found or not.
    if (!(lastactive == null)) {
      const status = await dailytoken.findOneAndUpdate(
        { clinic: id, serviceStatus: lastactive.serviceStatus },
        { $set: { serviceStatus: 'Complate' } }
      );
    }
    const ActiveToken = await dailytoken.findOne({ clinic: id, serviceStatus: 'Active' });
    return ActiveToken.tokenNo;
  }

  // Active token are found or not.
  const findActiveuser = await dailytoken.findOne({
    clinic: id,
    serviceStatus: 'Active',
    createdAt: {
      $gte: moment(moment().format('YYYY-MM-DD')).format('YYYY-MM-DD HH:mm:ss.SSS[Z]'),
      $lt: moment(moment(moment().add(1, 'days')).format('YYYY-MM-DD')).format('YYYY-MM-DD HH:mm:ss.SSS[Z]'),
    },
  });
  if (findActiveuser) {
    const updateActiveuser = await dailytoken.findOneAndUpdate(
      { clinic: id, serviceStatus: findActiveuser.serviceStatus, createdAt: findActiveuser.createdAt },
      { $set: { serviceStatus: 'Complate' } }
    );
    const tokennolast = await dailytoken.find({
      clinic: id,
      $or: [{ serviceStatus: 'Pending' }, { serviceStatus: 'Active' }],
      createdAt: findActiveuser.createdAt,
    });
    // pending and Active token are found or not.
    if (!tokennolast[0]) {
      throw new ApiError(httpStatus.NOT_FOUND, 'All token are Complate No pending token');
    }
    return findActiveuser.tokenNo;
  }
};

/**
 *
 * @param {import('mongoose').ObjectId} id
 * @returns
 */
const getAllToken = async (filter, options) => {
  filter.createdAt = {
    $gte: moment(moment().format('YYYY-MM-DD')).format('YYYY-MM-DD HH:mm:ss.SSS[Z]'),
    $lt: moment(moment(moment().add(1, 'days')).format('YYYY-MM-DD')).format('YYYY-MM-DD HH:mm:ss.SSS[Z]'),
  };
  return dailytoken.paginate(filter, options);
};

/**
 * Find Active token
 * @param {import('mongoose').ObjectId} id
 * @returns
 */
const currentToken = async (id) => {
  const ActiveToken = await dailytoken.findOne({
    clinic: id,
    serviceStatus: 'Active',
    createdAt: {
      $gte: moment(moment().format('YYYY-MM-DD')).format('YYYY-MM-DD HH:mm:ss.SSS[Z]'),
      $lt: moment(moment(moment().add(1, 'days')).format('YYYY-MM-DD')).format('YYYY-MM-DD HH:mm:ss.SSS[Z]'),
    },
  });
  if (ActiveToken) {
    return { tokenNo: ActiveToken.tokenNo };
  } else {
    throw new ApiError(httpStatus.NOT_FOUND, 'Now no any Token Are Active.');
  }
};

// PUT: Cancel Token by user.
const cencelcurrenttoken = async (id, tokenno) => {
  const status = await dailytoken.findOne({ clinic: id, tokenNo: tokenno });
  const update = await dailytoken.findOneAndUpdate(
    { clinic: id, tokenNo: tokenno, serviceStatus: status.serviceStatus },
    { $set: { serviceStatus: 'Cancelled' } }
  );
};

const cancelToken = async (clinic, user, tokenNo) => {
  const ExistToken = await dailytoken.findOne({
    clinic: clinic,
    user: user,
    tokenNo: tokenNo,
    serviceStatus: 'Pending',
  });
  if (ExistToken) {
    const cancelledToken = await dailytoken.findOneAndUpdate(
      { clinic: clinic, user: user, tokenNo: tokenNo, serviceStatus: 'Pending' },
      { $set: { serviceStatus: 'Cancelled' } }
    );
    return cancelledToken;
  } else {
    throw new ApiError(httpStatus.NOT_FOUND, 'Invalid Token');
  }
};

// All Modules are Exports from here 👇
module.exports = {
  bookingtoken,
  getTokenData,
  findbytoken,
  findbyclinicid,
  findbyuserid,
  changeTokenStatus,
  getAllToken,
  currentToken,
  cencelcurrenttoken,
  cancelToken,
};
