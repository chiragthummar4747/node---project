const httpStatus = require('http-status');
const { servicefeedback, clinic, dailytoken } = require('../models');
const ApiError = require('../utils/ApiError');
const service = require('../models/services.model');
const User = require('../models/user.model');

// create feedback
const createfeedback = async (id, data) => {
  const findservice = await service.find({ _id: data.service });
  if (!findservice) {
    throw new ApiError(httpStatus.NOT_FOUND, 'service are not found');
  }
  const finddailytoken = await dailytoken.findOne({ tokenId: data.tokenId });
  if (!finddailytoken) {
    throw new ApiError(httpStatus.NOT_FOUND, 'tokenId are not found');
  }
  return servicefeedback.create(data);
};

/**
 * 
 * @param {String} id 
 * @returns {Promise}
 */
const getServiceFeedbackByObjectId = async (id) => {
  return servicefeedback.findById(id);
};

// update feedback
/**
 * 
 * @param {Object} id 
 * @param {Object} data 
 * @returns {Promise}
 */
const updatefeedback = async ({ id }, data) => {
  const findservice = await service.find({ _id: data.service });
  if (!findservice) {
    throw new ApiError(httpStatus.NOT_FOUND, 'service are not found');
  }
  const finddailytoken = await dailytoken.findOne({ tokenId: data.tokenId });
  if (!finddailytoken) {
    throw new ApiError(httpStatus.NOT_FOUND, 'tokenId are not found');
  }
  const updateOne = servicefeedback.findOneAndUpdate(
    { _id: id },
    {
      ...data,
    },
    {
      new: true,
    }
  );
  return updateOne;
};

//Soft Delete feedback
/**
 * 
 * @param {Object} param0 
 * @returns {Promise}
 */
const deletefeedback = async ({ id }) => {
  return servicefeedback.findByIdAndUpdate(
    { _id: id },
    {
      $set: {
        deletedAt: new Date(),
      },
    }
  );
};

// find all(deletedAt : null) feedback
const findallfeedback = async () => {
  return await servicefeedback.find({ deleteAt: null }).populate('user service');
};
module.exports = {
  createfeedback,
  updatefeedback,
  deletefeedback,
  findallfeedback,
  getServiceFeedbackByObjectId,
};
