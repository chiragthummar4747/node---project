const { service } = require('../models');

// POST: Create a Services
const createservice = async (data) => service.create(data);

// GET: Show all data(deleteAt:null) from service Table
const getService = async () => service.find({ deletedAt: null });

/**
 * Update Service by ObjectId
 * @param {import('mongoose').ObjectId} id
 * @param {Object} data
 * @returns {Promise}
 */
const updateService = async (id, data) => {
  return service.findOneAndUpdate(
    { _id: id },
    {
      $set: {
        ...data,
      },
    },
    { new: true }
  );
};

// Soft DELETE category in 'categories' collection
/**
 *
 * @param {ObjectId} id
 * @returns {Promise}
 */
const deleteService = async (id) =>
  service.findOneAndUpdate({ _id: id }, { $set: { deletedAt: new Date() } }, { new: true });

/**
 *
 * @param {String} id
 * @returns {Promise}
 */
const getServiceByObjectId = async (id) => {
  return service.findById(id);
};

// All Modules are Exports from here 👇
module.exports = {
  createservice,
  getService,
  deleteService,
  updateService,
  getServiceByObjectId,
};
