const { clinic, Offer } = require('../models');


// create offer collection
/**
 * 
 * @param {Object} payload 
 * @returns {Object}
 */
const createOffer = async (payload) => Offer.create(payload);

// Find clinic in database
/**
 * 
 * @param {import('mongoose').ObjectId} clinicId 
 * @returns {Object}
 */
const clinicExist = async (clinicId) => clinic.findOne({ _id: clinicId });

// get all offers
/**
 * 
 * @param {Object} filter 
 * @param {Object} options 
 * @returns {Object}
 */
const getAllOffer = async (filter, options) => Offer.paginate(filter, options);

// Find offer in database
/**
 * 
 * @param {import('mongoose').ObjectId} offerId 
 * @returns {Object}
 */
const offerExist = async (offerId) => Offer.findOne({ _id: offerId });

// update offer data
/**
 *
 * @param {import('mongoose').ObjectId} offerId
 * @param {Object} data
 * @returns {Object}
 */
const updateOffer = async (offerId, data) => Offer.findOneAndUpdate({ _id: offerId }, { $set: { ...data } }, { new: true })


// get offer by Id
/**
 * 
 * @param {import('mongoose').ObjectId} offerId 
 * @returns {Object}
 */
const getOfferById = async (offerId) => Offer.findOne({ _id: offerId }).populate({ path: 'clinicId', populate: { path: 'doctor' } });

/**
 * delete offer in offer collection
 * @param {import('mongoose').ObjectId} clinicId
 * @returns {Object}
 */
const deleteOffer = async (clinicId) => Offer.findByIdAndUpdate({ _id: clinicId }, { $set: { deletedAt: new Date() } });

// All Modules are Exports from here 👇
module.exports = {
  createOffer,
  clinicExist,
  getAllOffer,
  offerExist,
  getOfferById,
  updateOffer,
  deleteOffer,
};
