const httpStatus = require('http-status');
const { clinicservice, service, clinic } = require('../models');
const ApiError = require('../utils/ApiError');

// create clinicService 'clinic_service' collection.
const createClinicService = async (data) => {
  return clinicservice.create(data);
};

// Get Clinic Service data from 'clinic_service' collection.
const getClinicService = async (filter, options) => {
  return clinicservice.paginate(filter, options);
};

// Find by clinicID from 'clinic' collection.
const findbyclinicid = async (id) => {
  return clinic.findById(id);
};

// Find by services from 'service' collection.
const findbyserviceid = async (id) => {
  return service.findById(id);
};

// All Modules are Exports from here 👇
module.exports = {
  createClinicService,
  getClinicService,
  findbyclinicid,
  findbyserviceid,
};
