const { Categories } = require('../models');

// create category in 'categories' collection.
const createCategories = async (categoriesData) => {
  return Categories.create(categoriesData);
};

// get all category(deletedAt : null) and search category in 'categories' collection.
const getCategories = async () => {
  return Categories.find({ deletedAt: null });
};

// find category id
const getCategoriesById = async (id) => {
  return Categories.findOne({ _id: id });
};

// UPDATE category in 'categories' collection
const updateCategories = async (id, data) => {
  return Categories.findOneAndUpdate(
    { _id: id },
    {
      $set: {
        ...data,
      },
    },
    {
      new: true,
    }
  );
};

// Soft DELETE category in 'categories' collection
const deleteCategories = async (id) => {
  return Categories.findOneAndUpdate(
    { _id: id },
    {
      $set: {
        deletedAt: new Date(),
      },
    }
  );
};

// All Modules are Exports from here 👇
module.exports = {
  createCategories,
  getCategories,
  getCategoriesById,
  updateCategories,
  deleteCategories,
};
