const { role, dailytoken, User, clinic, doctor } = require('../models');
const moment = require('moment');

/**
 *
 * @param {Objectimport('mongoose').Id} roleId
 * @returns {string} --> role
 */
const getRole = async (roleId) => (await role.findOne({ _id: roleId })).role;

/**
 * Get Dashboard details
 * 1. totalClinics
 * 2. totalDoctors
 * 3. totalClients
 * 4. totalTodayAppointments
 * @returns {Object}
 */
const getDashboard = async () => {
  const [totalClinics, totalDoctors, totalTodayAppointments, totalClients] = await Promise.all([
    clinic.count(),
    doctor.count(),
    dailytoken
      .find({
        createdAt: {
          $gte: moment(moment().format('YYYY-MM-DD')).format('YYYY-MM-DD HH:mm:ss.SSS[Z]'),
          $lt: moment(moment(moment().add(1, 'days')).format('YYYY-MM-DD')).format('YYYY-MM-DD HH:mm:ss.SSS[Z]'),
        },
      })
      .count(),
    User.count(),
  ]);
  return { totalClinics, totalDoctors, totalTodayAppointments, totalClients };
};

// get Patient, Clinic Data And Doctorlist Arr
/**
 * 
 * @param {Array} patientDataQuery 
 * @param {Array} clinicDataQuery 
 * @returns {Object}
 */
const getPatientAndClinicData = async (patientDataQuery, clinicDataQuery) => {
  const [patientData, clinicData, doctorArr] = await Promise.all([
    dailytoken.aggregate(patientDataQuery),
    dailytoken.aggregate(clinicDataQuery),
    clinic.find().select("clinicName")
  ])
  return { patientData, clinicData, doctorArr }

};

// All Modules are Exports from here 👇
module.exports = {
  getDashboard,
  getRole,
  getPatientAndClinicData
};

