const auth = require('../middlewares/auth');
const clinic = require('../models/clinic.model');
const dailytoken = require('../models/dailytoken.model');
const dailytokenservices = require('./dailytoken.service');

module.exports.socketIO = function (io) {
  // Authentication usage
  // io.use(auth.authSocketIO);

  // ***************************************
  // Token Book in clinic API
  // ***************************************
  io.on('connection', async (socket) => {
    socket.on('bookToken', async function (data) {
      const ExistClinic = await dailytokenservices.findbyclinicid(data.clinic);
      const ExistUser = await dailytokenservices.findbyuserid(data.user);
      // Check clinic are Exist or not in database
      if (!ExistClinic) {
        socket.emit('bookToken', 'Clinic are Not Found');
      }
      // Check User are Exist or not in database
      else if (!ExistUser) {
        socket.emit('bookToken', 'User are Not Found');
      } else {
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        // Generate a Token ID
        function generateString(length) {
          let result = ' ';
          const charactersLength = characters.length;
          for (let i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
          }
          return result;
        }
        const tokenBook = await dailytokenservices.bookingtoken({ tokenId: generateString(8) }, data.clinic, data.user);
        socket.emit('bookToken', tokenBook);
      }
    });

    // ***************************************
    // Current Token API using Socket.io
    // ***************************************

    socket.on('currentToken', async function (data) {
      const clinicExist = await clinic.findById(data);
      const bookClinic = await dailytoken.findOne({ clinic: data });
      if (!clinicExist) {
        socket.emit('currentToken', 'Clinic are not Found');
        // throw new ApiError(httpStatus.NOT_FOUND, 'Clinic are not Found');
      } else if (!bookClinic) {
        socket.emit('currentToken', 'No any Tokens are book now');
        // throw new ApiError(httpStatus.NOT_FOUND, 'No any Tokens are book now');
      } else {
        const currentToken = await dailytoken.findOne({ clinic: data, serviceStatus: 'Active' });
        if (currentToken) {
          socket.emit('currentToken', `Active Token No.: ${currentToken.tokenNo}`);
        } else {
          socket.emit('currentToken', 'Now no any Token are Active');
        }
      }
    });

    // ***************************************
    // Cancel Token API using Socket.io
    // ***************************************

    socket.on('cancelToken', async function (data) {
      const ExistToken = await dailytoken.findOne({
        clinic: data.clinic,
        user: data.user,
        tokenNo: data.tokenNo,
        serviceStatus: 'Pending',
      });
      if (ExistToken) {
        socket.emit('cancelToken', 'Token Cancel Successfully');
        const cancelledToken = await dailytoken.findOneAndUpdate(
          { clinic: data.clinic, user: data.user, tokenNo: data.tokenNo, serviceStatus: 'Pending' },
          { $set: { serviceStatus: 'Cancelled' } }
        );
      } else {
        socket.emit('cancelToken', 'Invalid Token');
      }
    });
  });

  io.on('disconnect', function () {
    console.log('You are Disconnected from Booking Token socket .');
  });
};
