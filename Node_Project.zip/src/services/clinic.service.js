const moment = require('moment');
const mongoose = require('mongoose');
const { clinic, role, doctor, dailytoken } = require('../models');

// create clinic collection
/**
 *
 * @param {Object} payload
 * @returns {Object}
 */
const createclinics = async (payload) => {
  return clinic.create(payload);
};

/**
 * find by clinic id
 * @param {import('mongoose').ObjectId} id
 * @returns
 */
const findbyid = async (id) => {
  return clinic.findById(id);
};

/**
 * delete clinic in clinic collection
 * @param {import('mongoose').ObjectId} id
 * @returns {Object}
 */
const deleteclinic = async (id) => {
  return clinic.findByIdAndUpdate(
    { _id: id },
    {
      $set: {
        deletedAt: new Date(),
      },
    }
  );
};

/**
 * find clinic data from clinic collecton
 * @returns {Array}
 */
const finddata = async () => {
  return clinic.find({});
};

/**
 * get clinic data in clinic collection
 * @param {import('mongoose').ObjectId} id
 * @returns {Object}
 */
const getclinicuser = async (id) => {
  return clinic.findOne(id).populate('category , service , doctor');
};

/**
 * get All Clinic Data
 * @param {import('mongoose').ObjectId} id
 * @param {Number} page
 * @param {Number} limit
 * @param {Number} skip
 * @param {Object} search
 * @returns
 */
const getClinicUser = async (id, page, limit, skip, search) => {
  return clinic.aggregate([
    {
      $match: {
        _id: mongoose.Types.ObjectId(id),
      },
    },
    {
      $lookup: {
        from: 'dailybookingtokens',
        localField: '_id',
        foreignField: 'clinic',
        as: 'clinic',
      },
    },
    {
      $lookup: {
        from: 'users',
        localField: 'clinic.user',
        foreignField: '_id',
        as: 'patients',
      },
    },
    {
      $project: {
        patients: 1,
      },
    },
    {
      $unwind: {
        path: '$patients',
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $match: {
        'patients.first_name': {
          $regex: search ? search : '', $options: 'i',
        },
      },
    },
    {
      $facet: {
        pagi: [
          {
            $count: 'totalResults',
          },
          {
            $addFields: {
              page: page,
              limit: limit,
              totalPages: {
                $ceil: {
                  $divide: ['$totalResults', limit],
                },
              },
            },
          },
        ],
        data: [
          {
            $skip: skip,
          },
          {
            $limit: limit,
          },
        ],
      },
    },
    {
      $unwind: {
        path: '$pagi',
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $replaceRoot: {
        newRoot: {
          $mergeObjects: [
            {
              results: '$data',
            },
            '$pagi',
          ],
        },
      },
    },
  ]);
};

/**
 * Get Clinic By location
 * @param {Object} query
 * @returns {Promise}
 */
const getlocationwiseclinic = async (query) => {
  const clinicData = await clinic.aggregate(query);
  return clinicData[0];
};

/**
 * Update clinic data in clinic collection
 * @param {Objectimport('mongoose').Id} id
 * @param {Object} data
 * @returns {Object}
 */
const updateClinic = async (id, data) => {
  return clinic.findOneAndUpdate(
    { _id: id },
    {
      $set: {
        ...data,
      },
    },
    { new: true }
  );
};

/**
 * get clinic in clinic collection
 * @param {Object} filter
 * @param {Object} options
 * @returns {Array}
 */
const getClinic = async (filter, options) => {
  return clinic.paginate(filter, options);
};

/**
 * get clinic from clinic collection
 */
const getClinicDropDown = async (doctorId) => {
  return clinic.find({ doctor: doctorId }).select('id clinicName');
};

/**
 *
 * @returns {Promise}
 */
const getAllClinic = async (pagination, skip, search, filter) => {
  const allClinicData = await clinic.aggregate([
    {
      $match: {
        ...filter,
      },
    },
    {
      $lookup: {
        from: 'services',
        localField: 'service',
        foreignField: '_id',
        as: 'services_details',
      },
    },
    {
      $lookup: {
        from: 'categories',
        localField: 'category',
        foreignField: '_id',
        as: 'categories_details',
      },
    },
    {
      $lookup: {
        from: 'dailybookingtokens',
        localField: '_id',
        foreignField: 'clinic',
        as: 'dailybookingtokens_details',
      },
    },
    {
      $addFields: {
        todayBookingTokens: {
          $reduce: {
            input: '$dailybookingtokens_details',
            initialValue: 0,
            in: {
              $add: [
                '$$value',
                {
                  $cond: {
                    if: {
                      $and: [
                        {
                          $gte: ['$$this.createdAt', new Date(moment().subtract(1, 'days').format('YYYY-MM-DD'))],
                        },
                        {
                          $lt: ['$$this.createdAt', new Date(moment().add(1, 'days').format('YYYY-MM-DD'))],
                        },
                      ],
                    },
                    then: 1,
                    else: 0,
                  },
                },
              ],
            },
          },
        },
      },
    },
    {
      $project: {
        dailybookingtokens_details: 0,
      },
    },
    {
      $facet: {
        pagi: [
          {
            $count: 'totalResults',
          },
          {
            $addFields: {
              page: pagination.page,
              limit: pagination.limit,
              totalPages: {
                $ceil: {
                  $divide: ['$totalResults', pagination.limit],
                },
              },
            },
          },
        ],
        data: [
          {
            $skip: skip,
          },
          {
            $limit: pagination.limit,
          },
        ],
      },
    },
    {
      $unwind: {
        path: '$pagi',
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $replaceRoot: {
        newRoot: {
          $mergeObjects: [
            {
              results: '$data',
            },
            '$pagi',
          ],
        },
      },
    },
  ]);
  return allClinicData;
};

// find token in clinic token
const findtoken = async (payload) => {
  return clinic.find({ payload });
};

/**
 * Find Doctor by ObjectId
 * @param {import('mongoose').ObjectId} doctorId
 * @returns {Object}
 */
const findDoctor = async (doctorId) => {
  return doctor.findById(doctorId);
};

/**
 * Find Clinic (Doctor Created)
 * @param {import('mongoose').ObjectId} doctorID
 * @returns {Array}
 */
const getClinicForDoctor = async (doctorID) => {
  return clinic.find({ doctor: doctorID });
};

/**
 *
 * @param {Objectimport('mongoose').Id} id
 * @returns {Object}
 */
const findRole = async (id) => {
  return role.findById(id);
};
/**
 * Get Appointment history
 * @param {Object} filter
 * @param {Object} options
 */
const clinicAppointmentHistory = async (query) => {
  const appointmentHistory = await dailytoken.aggregate(query);
  return appointmentHistory[0];
};

/**
 *
 * @param {Objectimport('mongoose').Id} clinicId
 * @returns {Object}
 */
const getClinicDahboard = async (clinicId) => {
  const [totalAppointments, patientDetails] = await Promise.all([
    dailytoken.find({ clinic: mongoose.Types.ObjectId(clinicId) }).count(),
    dailytoken.aggregate([
      {
        $match: {
          clinic: mongoose.Types.ObjectId(clinicId),
        },
      },
      {
        $lookup: {
          from: 'users',
          localField: 'user',
          foreignField: '_id',
          as: 'user_details',
        },
      },
      {
        $addFields: {
          user_details: {
            $arrayElemAt: ['$user_details', 0],
          },
        },
      },
      {
        $group: {
          _id: '$user_details',
        },
      },
    ]),
  ]);
  return { totalAppointments, totalPatients: patientDetails.length, patientDetails };
};

// All Modules are Exports from here 👇
module.exports = {
  createclinics,
  findbyid,
  deleteclinic,
  finddata,
  getclinicuser,
  updateClinic,
  getClinic,
  findtoken,
  findDoctor,
  getClinicForDoctor,
  getAllClinic,
  getClinicUser,
  getlocationwiseclinic,
  clinicAppointmentHistory,
  findRole,
  getClinicDahboard,
  getClinicDropDown,
};
