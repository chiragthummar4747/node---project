const httpStatus = require('http-status');
const { Country } = require('../models');
const ApiError = require('../utils/ApiError');

// INSERT Country data in 'country' table.
const createCountry = async (countryData) => (await Country.findOne({ country_name: countryData.country_name })) ? (function () { throw new ApiError(httpStatus.ALREADY_REPORTED, 'Country are already Use') }()) : Country.create({ ...countryData });

// Get All Country data from 'country' table.
const getCountry = async (filter, options) => Country.paginate(filter, options);

// GET Country by ObjectID from 'country' table.
const getCountryById = async (id) => Country.findById(id);

// UPDATE Country by ObjectID from 'country' table.
const updateCountry = async (id, data) => Country.findOneAndUpdate({ _id: id }, { $set: { ...data, } }, { new: true });

// DELETE Country data by ObjectID from 'country' table.
const deleteCountry = async (id) => Country.deleteOne({ _id: id });

// All Modules are Exports from here 👇
module.exports = {
  createCountry,
  getCountry,
  getCountryById,
  updateCountry,
  deleteCountry,
};
