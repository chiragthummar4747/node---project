const { clinic, Job } = require('../models');


// create Job collection
/**
 * 
 * @param {Object} payload 
 * @returns {Object}
 */
const createJob = async (payload) => Job.create(payload);

// Find clinic in database
/**
 * 
 * @param {import('mongoose').ObjectId} clinicId 
 * @returns {Object}
 */
const clinicExist = async (clinicId) => clinic.findOne({ _id: clinicId });

// get all Jobs
/**
 * 
 * @param {Object} filter 
 * @param {Object} options 
 * @returns {Object}
 */
const getAllJob = async (filter, options) => Job.paginate(filter, options);

// Find Job in database
/**
 * 
 * @param {import('mongoose').ObjectId} jobid 
 * @returns {Object}
 */
const JobExist = async (jobid) => Job.findOne({ _id: jobid })

// update Job data
/**
 *
 * @param {import('mongoose').ObjectId} jobid
 * @param {Object} data
 * @returns {Object}
 */
const updateJob = async (jobid, data) => Job.findOneAndUpdate({ _id: jobid }, { $set: { ...data } }, { new: true })


// get Job by Id
/**
 * 
 * @param {import('mongoose').ObjectId} jobid 
 * @returns {Object}
 */
const getJobById = async (jobid) => Job.findOne({ _id: jobid }).populate({ path: 'clinicId', populate: { path: 'doctor' } })

/**
 * delete Job in Job collection
 * @param {import('mongoose').ObjectId} clinicId
 * @returns {Object}
 */
const deleteJob = async (clinicId) => Job.findByIdAndUpdate({ _id: clinicId }, { $set: { deletedAt: new Date() } });

// All Modules are Exports from here 👇
module.exports = {
  createJob,
  clinicExist,
  getAllJob,
  JobExist,
  getJobById,
  updateJob,
  deleteJob,
};
