const { cityList } = require('./IndianCity');
const cityModel = require('../models/city.model');
const countryModel = require('../models/country.model');
const httpStatus = require('http-status');
const ApiError = require('../utils/ApiError');

const allCityList = async (country) => {
  const ExistCountry = await countryModel.findById(country);
  if (!ExistCountry) {
    throw new ApiError(httpStatus.NOT_FOUND, 'This Country are Not Found!');
  }

  cityList.forEach((city) => {
    cityModel.create({ city_name: city, country: country }); // Add here your database's country ID.
  });
};

module.exports = { allCityList };
