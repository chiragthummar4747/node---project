const allRoles = {
  User: 'User',
  SuperAdmin: 'Super Admin',
  Doctor: 'Doctor',
};

const roles = Object.values(allRoles);
const roleRights = new Map(Object.entries(allRoles));

module.exports = {
  roles,
  roleRights,
};
