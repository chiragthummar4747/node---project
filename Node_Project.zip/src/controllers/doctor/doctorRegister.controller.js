const httpStatus = require('http-status');
const catchAsync = require('../../utils/catchAsync');
const ApiError = require('../../utils/ApiError');
const { tokenService, doctorService } = require('../../services');
const pick = require('../../utils/pick');
const mongoose = require('mongoose');

// Doctor Register
const doctorRegister = catchAsync(async (req, res) =>
  (await doctorService.getUserByEmail(req.body.email))
    ? (function () {
      throw new ApiError(httpStatus.BAD_REQUEST, 'This Email-id is already registered, Please login.');
    })()
    : res.status(200).json({
      success: true,
      msg: `Send mail to ${req.body.email} successfully...!, Please check Email`,
      data: await doctorService.doctorRegister(req.body.email),
    })
);

// doctor login
const doctorLogin = catchAsync(async (req, res) => {
  const doctorExist = await doctorService.getUserByEmail(req.body.email);
  !doctorExist || !(await doctorExist.isPasswordMatch(req.body.password))
    ? (function () {
      throw new ApiError(httpStatus.BAD_REQUEST, 'Incorrect email or password');
    })()
    : 0;
  const doctor = await doctorService.doctorLogin(req.body.email);
  res
    .status(200)
    .json({ success: true, msg: 'Login Successfully', data: doctor, token: await tokenService.generateAuthTokens(doctor) });
});

// get all doctor data
const getAllDoctor = catchAsync(async (req, res) => {
  const filter = { deletedAt: null };
  const [{ search }, option] = [pick(req.query, ['search']), pick(req.query, ['sortBy', 'limit', 'page'])];
  search ? (filter.first_name = new RegExp(search, 'i')) : 0;
  res.status(httpStatus.OK).json({
    sucess: true,
    msg: 'All doctor data get sucessfully',
    search,
    data: await doctorService.getAllDoctor(filter, option),
  });
});

// Update Doctor Profile
const updateDoctorProfile = catchAsync(async (req, res) =>
  !(await doctorService.getDoctorByObjectId(req.params.id))
    ? (function () {
      throw new ApiError(404, 'Doctor are not found');
    })()
    : res.status(httpStatus.CREATED).json({
      success: true,
      msg: 'Update Your Profile Successfully...!',
      data: req.file
        ? await doctorService.updateDoctorProfile(req.params.id, { ...req.body, doctorImage: req.file.filename })
        : await doctorService.updateDoctorProfile(req.params.id, req.body),
    })
);

// Get doctor dashboard details
const getDoctorDashboard = catchAsync(async (req, res) =>
  res.status(httpStatus.OK).json({
    success: true,
    data: await doctorService.totalClinicAndAppointment(),
    msg: 'Dashboard data get successfully...!',
  })
);

// get doctor profile
const getDoctorProfile = catchAsync(async (req, res) => {
  res.status(httpStatus.OK).json({
    success: true,
    msg: 'Doctor profile get sucessfully',
    data: await doctorService.getDoctorProfile(req.user._id),
  });
});

// get doctor profile by id
const getDoctorProfileById = catchAsync(async (req, res) => {
  !(await doctorService.getDoctorByObjectId(req.params.doctorId))
    ? (function () {
      throw new ApiError(httpStatus.NOT_FOUND, 'Doctor not found');
    })()
    : 0;

  const { search } = pick(req.query, ['search']);
  const options = pick(req.query, ['limit', 'page']);

  const pagination = {
    limit: Number(options.limit),
    page: Number(options.page),
  };

  const skip = ((pagination.page || 1) - 1) * pagination.limit;

  let filter = {
    _id: mongoose.Types.ObjectId(req.params.doctorId),
  };

  const query = [
    {
      $match: {
        ...filter,
      },
    },
    {
      $lookup: {
        from: 'clinics',
        localField: '_id',
        foreignField: 'doctor',
        pipeline: [
          {
            $match: {
              clinicName: { $regex: search ? search : '', $options: 'i' },
            },
          },
          {
            $lookup: {
              from: 'services',
              localField: 'service',
              foreignField: '_id',
              as: 'service',
            },
          },
          {
            $facet: {
              pagination: [
                {
                  $count: 'totalResults',
                },
                {
                  $addFields: {
                    page: pagination.page,
                    limit: pagination.limit,
                    totalPages: {
                      $ceil: {
                        $divide: ['$totalResults', pagination.limit],
                      },
                    },
                  },
                },
              ],
              results: [
                { $skip: skip },
                {
                  $limit: pagination.limit,
                },
              ],
            },
          },
          {
            $unwind: {
              path: '$pagination',
              preserveNullAndEmptyArrays: true,
            },
          },
          {
            $replaceRoot: {
              newRoot: {
                $mergeObjects: [
                  {
                    results: '$results',
                  },
                  '$pagination',
                ],
              },
            },
          },
        ],
        as: 'clinics_details',
      },
    },
    {
      $unwind: {
        path: '$clinics_details',
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $project: {
        password: 0,
      },
    },
  ];
  const result = await doctorService.getDoctorProfileById(query);

  res.status(httpStatus.OK).json({
    success: true,
    msg: 'Doctor profile get sucessfully',
    data: result,
  });
});

// All modules are exports from here
module.exports = {
  doctorRegister,
  doctorLogin,
  getAllDoctor,
  updateDoctorProfile,
  getDoctorDashboard,
  getDoctorProfile,
  getDoctorProfileById,
};
