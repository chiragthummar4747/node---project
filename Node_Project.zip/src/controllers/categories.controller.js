const httpStatus = require('http-status');
const pick = require('../utils/pick');
const ApiError = require('../utils/ApiError');
const catchAsync = require('../utils/catchAsync');
const { categoriesService } = require('../services');
const data = require('../models/categories.model');

// POST: Create Category
const createCategories = catchAsync(async (req, res) => {
  const categories = await categoriesService.createCategories({ ...req.body });
  res.status(httpStatus.CREATED).json({ success: true, msg: 'Category created successfully...!', data: categories });
});

// GET: find all category from here
const getCategories = catchAsync(async (req, res) => {
  const categories = await categoriesService.getCategories();
  res.status(httpStatus.OK).json({ success: true, msg: 'get Category data successfully', data: categories });
});

// GET: find category by ObjectID
const getCategoriesById = catchAsync(async (req, res) => {
  const getData = await categoriesService.getCategoriesById(req.params.id);
  // Check category are found or not in database
  if (!getData) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Categories are not found');
  }
  res.status(httpStatus.OK).json({ success: true, msg: 'get Category data successfully', data: getData });
});

// PUT: Update Category by ObjectID
const updateCategories = catchAsync(async (req, res) => {
  const findById = await categoriesService.getCategoriesById(req.params.id);
  // Check category are found or not in database
  if (!findById) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Categories are not found');
  }

  const updateCategory = await categoriesService.updateCategories(findById, req.body);
  res.status(httpStatus.OK).json({ success: true, msg: 'Categories Data UPDATE successfully...!', data: updateCategory });
});

// DELETE: Delete Category by ObjectID
const deleteCategories = catchAsync(async (req, res) => {
  const getData = await categoriesService.getCategoriesById(req.params.id);
  // Check category are found or not in database
  if (!getData) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Categories are not found');
  }
  const deleteData = await categoriesService.deleteCategories(req.params.id);
  res.status(httpStatus.OK).json({ success: true, msg: 'This Category are Deleted successfully...!', data: getData });
});

// All Modules are Exports from here 👇
module.exports = {
  createCategories,
  getCategories,
  getCategoriesById,
  updateCategories,
  deleteCategories,
};
