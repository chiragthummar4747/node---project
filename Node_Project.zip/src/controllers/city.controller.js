const httpStatus = require('http-status');
const catchAsync = require('../utils/catchAsync');
const pick = require('../utils/pick');
const ApiError = require('../utils/ApiError');
const cityService = require('../services/city.service');
const cityList = require('../seeder/seeder');

// Using Seeder insert data in 'city' collection.
const AllCityList = catchAsync(async (req, res) => {
  const allcitylist = await cityList.allCityList(req.body.country);
  res.status(httpStatus.OK).json({ success: true, msg: 'City data created successfully...!' });
});
// End: seeder

// POST: Add new city in database
const createCity = catchAsync(async (req, res) => res.status(httpStatus.OK).json({ success: true, msg: 'City created successfully', cityData: await cityService.createCity(req.body) }));

// GET: Show all city data
const getCity = catchAsync(async (req, res) => res.status(httpStatus.OK).json({ success: true, msg: 'CityData', city: await cityService.getCity({ isActive: true, city_name: pick(req.query, ['search']).search ? { $regex: pick(req.query, ['search']).search, $options: "i" } : { $regex: '', $options: "i" } }, pick(req.query, ['sortBy', 'limit', 'page'])) }));

// GET: show city data by ObjectID
const getCityById = catchAsync(async (req, res) => (!await cityService.getCityById(req.params.cityId)) ? (function () { throw new ApiError(httpStatus.NOT_FOUND, 'City are not Found') }()) : res.status(httpStatus.OK).json({ success: true, msg: 'City find Successfully...!', getdataById: await cityService.getCityById(req.params.cityId) }));

// GET: Show city data by Country
const getCityByCountry = catchAsync(async (req, res) => res.status(httpStatus.OK).json({ success: true, msg: 'CityData', Country: req.params.countryID, city: await cityService.getCity({ country: req.params.countryID, isActive: true, city_name: pick(req.query, ['search']).search ? { $regex: pick(req.query, ['search']).search, $options: "i" } : { $regex: '', $options: "i" } }, pick(req.query, ['sortBy', 'limit', 'page'])) }));

// PUT: Update city data by ObjectID
const updateCity = catchAsync(async (req, res) => (!await cityService.getCityById(req.params.cityId)) ? (function () { throw new ApiError(httpStatus.NOT_FOUND, 'City are not Found') })() : res.status(httpStatus.OK).json({ success: true, msg: 'City Data Updated successfully', updateData: req.body, A: await cityService.updateCity(req.params.cityId, req.body) }));

// DELETE: Delete City data by ObjectID
const deleteCity = catchAsync(async (req, res) => (!await cityService.getCityById(req.params.cityId)) ? (function () { throw new ApiError(httpStatus.NOT_FOUND, 'City are not Found') })() : res.status(httpStatus.OK).json({ success: true, msg: 'City Data deleted successfully', deleteData: await cityService.deleteCity(req.params.cityId) }));

// All Modules are Exports from here 👇
module.exports = {
  AllCityList,
  createCity,
  getCity,
  getCityById,
  getCityByCountry,
  updateCity,
  deleteCity,
};
