const catchAsync = require('../utils/catchAsync');
const httpStatus = require('http-status');
const roleservices = require('../services/role.service');

// POST: Create a Role
const createroleuser = catchAsync(async (req, res) => {
  const role = await roleservices.createuser(req.body);
  res.status(httpStatus.OK).json({ success: true, msg: 'Role Created Successfully...!', role });
});

// All Modules are Exports from here 👇
module.exports = {
  createroleuser,
};
