const httpStatus = require('http-status');
const ApiError = require('../utils/ApiError');
const catchAsync = require('../utils/catchAsync');
const { serviceService } = require('../services');

// POST: Create a Services
const createservices = catchAsync(async (req, res) =>
  res
    .status(httpStatus.CREATED)
    .json({ success: true, msg: 'service created successfully...!', data: await serviceService.createservice(req.body) })
);

// GET: Show all data from service Table
const getService = catchAsync(async (req, res) =>
  res
    .status(httpStatus.OK)
    .json({ success: true, msg: 'Get all data from service collection..!', data: await serviceService.getService() })
);

// GET: Show Service By Object Id
const getServiceByObjectId = catchAsync(async (req, res) => {
  const ExistService = await serviceService.getServiceByObjectId(req.params.serviceId);
  if (!ExistService) {
    throw new ApiError(httpStatus.NOT_FOUND, 'This Service Are not found');
  }
  const serviceData = await serviceService.getServiceByObjectId(req.params.serviceId);
  res.status(httpStatus.OK).json({ success: true, msg: 'Get Service Data Successfully...!', data: serviceData });
});

// UPDATE: Update Service By Object Id
const updateService = catchAsync(async (req, res) => {
  const ExistService = await serviceService.getServiceByObjectId(req.params.serviceId);
  if (!ExistService) {
    throw new ApiError(httpStatus.NOT_FOUND, 'This Service Are not found');
  }
  const updateData = await serviceService.updateService(req.params.serviceId, req.body);
  res.status(httpStatus.OK).json({ success: true, msg: 'Service Updated Successfully...!', data: updateData });
});

// DELETE: Show all data from database(Soft delete)
const deleteservices = catchAsync(async (req, res) =>
  !(await serviceService.getServiceByObjectId(req.params.serviceId))
    ? (function () {
        throw new ApiError(404, 'This Service Are not found');
      })()
    : res.status(httpStatus.OK).json({
        success: true,
        msg: 'Deleted data successfully...!',
        data: await serviceService.deleteService(req.params.serviceId),
      })
);

// All Modules are Exports from here 👇
module.exports = {
  createservices,
  getService,
  getServiceByObjectId,
  updateService,
  deleteservices,
};
