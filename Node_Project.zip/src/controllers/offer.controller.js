const httpStatus = require('http-status');
const catchAsync = require('../utils/catchAsync');
const pick = require('../utils/pick');
const ApiError = require('../utils/ApiError');
const offerService = require('../services/offer.service');

// POST: Add new offer in database
const createOffer = catchAsync(async (req, res) => {

  const clinicExist = await offerService.clinicExist(req.body.clinicId);

  if (!clinicExist) throw new ApiError(httpStatus.NOT_FOUND, 'Clinic are not Found');

  const payload = { ...req.body };

  (req.file) ? payload.offerImage = req.file.filename : 0;

  const createOffer = await offerService.createOffer(payload);

  res.status(httpStatus.OK).json({ success: true, msg: 'Offer created successfully', data: createOffer });
});


// GET: show all offer data
const getAllOffer = catchAsync(async (req, res) => {
  const options = pick(req.query, ['page', 'limit', 'sortBy']);

  const { search } = pick(req.query, ['search']);

  let filter = { deletedAt: null, isActive: true };

  (search) ? filter.title = { $regex: search, $options: 'i' } : 0

  options.populate = 'clinicId.doctor'

  const getAllOffer = await offerService.getAllOffer(filter, options);

  res.status(httpStatus.OK).json({ success: true, msg: 'All offer data get successfully', data: getAllOffer });
});

// GET: Show offer data by ObjectID
const getOfferById = catchAsync(async (req, res) => {
  const offerExist = await offerService.offerExist(req.params.offerId);
  // Check offer are found or not in database.
  if (!offerExist) throw new ApiError(httpStatus.NOT_FOUND, 'offer are not found');

  const getOfferById = await offerService.getOfferById(req.params.offerId);

  res.status(httpStatus.OK).json({ success: true, msg: 'offer data find successfully', data: getOfferById });
});

// PUT: Update Doctor Profile
const updateOffer = catchAsync(async (req, res) => {
  const offerExist = await offerService.offerExist(req.params.offerId);
  // Check offer are found or not in database.
  if (!offerExist) throw new ApiError(httpStatus.NOT_FOUND, 'offer are not found');

  const updateOffer = (req.file) ? await offerService.updateOffer(req.params.offerId, { ...req.body, offerImage: req.file.filename }) : await offerService.updateOffer(req.params.offerId, req.body)

  res.status(httpStatus.CREATED).json({ success: true, msg: 'Update Your offer Successfully...!', data: updateOffer })
});

// DELETE: Delete offer by ObjectID
const deleteOffer = catchAsync(async (req, res) => {
  const offerExist = await offerService.offerExist(req.params.offerId);
  // Check offer are found or not in database.
  if (!offerExist) throw new ApiError(httpStatus.NOT_FOUND, 'offer are not found');

  await offerService.deleteOffer(req.params.offerId);

  res.status(200).json({ success: true, msg: 'offer delete successfully' });
});

// All Modules are Exports from here 👇
module.exports = {
  createOffer,
  getAllOffer,
  getOfferById,
  updateOffer,
  deleteOffer,
};
