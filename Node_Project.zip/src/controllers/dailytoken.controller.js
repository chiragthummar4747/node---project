const catchAsync = require('../utils/catchAsync');
const ApiError = require('../utils/ApiError');
const httpStatus = require('http-status');
const pick = require('../utils/pick');
const dailytokenservices = require('../services/dailytoken.service');
const clinic = require('../models/clinic.model');
const role = require('../models/role.model');

// POST: Booking Token
const bookingtoken = catchAsync(async (req, res) => {
  const ExistClinic = await dailytokenservices.findbyclinicid(req.body.clinic);

  if (!ExistClinic) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Clinic are Not Found');
  }

  const ExistUser = await dailytokenservices.findbyuserid(req.body.user);

  if (!ExistUser) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User are Not Found');
  }

  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  function generateString(length) {
    let result = ' ';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  }

  const tokenbooking = await dailytokenservices.bookingtoken({ tokenId: generateString(8) }, req.body.clinic, req.body.user);
  res.status(httpStatus.CREATED).json({ success: true, msg: 'booking token create successfully', data: tokenbooking });
});

// GET: Show All Token Data from database
const getTokenData = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['date']);
  const options = pick(req.query, ['sortBy', 'limit', 'page']);
  options.populate = 'clinic, user';
  const tokenData = await dailytokenservices.getTokenData(filter, options);
  res.status(httpStatus.OK).json({ success: true, msg: 'Get Token Data here ', data: tokenData });
});

// PUT: Which token are now current Token
const changeTokenStatus = catchAsync(async (req, res) => {
  const data = await dailytokenservices.changeTokenStatus(req.params.clinic);
  res.status(httpStatus.OK).json({ success: true, msg: 'Change Token Status Successfully...!', data: data });
});

//GET: Get today data
const getAllToken = catchAsync(async (req, res) => {
  const { search } = pick(req.query, ['search']);
  const options = await pick(req.query, ['sortBy', 'limit', 'page']);
  let filter = {};

  if (search) {
    filter.serviceStatus = { $regex: search };
  }
  filter.clinic = req.params.clinic;
  options.populate = 'user, clinic';
  // const data = await dailytokenservices.getAllToken(req.params.clinic);
  const data = await dailytokenservices.getAllToken(filter, options);

  if (data.results.length == 0) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Record not found!');
  }

  res.status(httpStatus.OK).json({ success: true, msg: "Get Today Appointment's data Successfully...!", data: data });
});

// GET: Show Active token No on clinic.
const currentToken = catchAsync(async (req, res) => {
  const clinicExist = await clinic.findById(req.body.clinic);
  if (!clinicExist) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Clinic are not Found');
  }
  const ActiveToken = await dailytokenservices.currentToken(req.body.clinic);
  res.status(httpStatus.OK).json({ success: true, msg: 'Active Token get successfully...!', data: ActiveToken });
});

// PUT: Cancel Token by user.
const cancelToken = catchAsync(async (req, res) => {
  const data = await dailytokenservices.cencelcurrenttoken(req.params.clinic, req.body.tokenNo);
  res.status(httpStatus.OK).json({ success: true, msg: `your token ${req.body.tokenNo} has been cancelled` });
});

// All Modules are Exports from here 👇
module.exports = {
  bookingtoken,
  getTokenData,
  changeTokenStatus,
  getAllToken,
  cancelToken,
  currentToken,
};
