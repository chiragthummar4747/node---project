const catchAsync = require('../utils/catchAsync');
const ApiError = require('../utils/ApiError');
const httpStatus = require('http-status');
const clinicService = require('../services/clinic.service');
const pick = require('../utils/pick');
const moment = require('moment');
const mongoose = require('mongoose');

// POST: Create a clinic
const createclinic = catchAsync(async (req, res) => {
  const findDoctor = await clinicService.findDoctor(req.user._id);

  if (!findDoctor) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'Doctor not found!');
  }

  let { body } = req;
  body.location = {
    type: 'Point',
    coordinates: [body.longitude, body.latitude],
  };

  const jsonArrayData = JSON.parse(req.body.service);
  const jsonObjectData = JSON.parse(req.body.openingHours);
  const payload = {
    ...req.body,
    doctor: req.user._id,
    openingHours: jsonObjectData,
    service: jsonArrayData,
  };

  if (req.file) {
    payload.clinicImage = req.file.filename;
  }

  const clinic = await clinicService.createclinics(payload);
  res.status(httpStatus.CREATED).json({ success: true, msg: 'Clinic create successfully', data: clinic });
});

// GET: show all clinic data
const getAllclinic = catchAsync(async (req, res) => {
  const { search, page, limit } = pick(req.query, ['search', 'page', 'limit']);
  const skip = ((Number(page) || 1) - 1) * Number(limit);
  const pagination = { limit: Number(limit), page: Number(page) };

  let filter = {
    deletedAt: null,
  };

  if (search) {
    filter.clinicName = { $regex: search, $options: 'i' };
  }

  const clinic = await clinicService.getAllClinic(pagination, skip, search, filter);

  res.status(httpStatus.OK).json({ success: true, msg: 'All clinic data get successfully', data: clinic[0] });
});

// GET: Show clinic data by ObjectID
const getclinicuser = catchAsync(async (req, res) => {
  const findById = await clinicService.findbyid(req.params.id);
  // Check clinic are found or not in database.
  if (!findById) {
    throw new ApiError(httpStatus.NOT_FOUND, 'clinic are not found');
  }
  const findidandgetdata = await clinicService.getclinicuser(findById._id);
  res.status(httpStatus.OK).json({ success: true, msg: 'clinic data find successfully', data: findidandgetdata });
});

// Get Clinic User
const getClinicUser = catchAsync(async (req, res) => {
  const { clinic_id } = pick(req.params, ['clinic_id']);
  const { page, limit, search } = pick(req.query, ['page', 'limit', 'search']);
  const skipCount = ((page || 1) - 1) * Number(limit);

  const clinicUser = await clinicService.getClinicUser(clinic_id, Number(page), Number(limit), skipCount, search);

  res.status(httpStatus.OK).json({ success: true, msg: 'clinic user get successfully.', data: clinicUser[0] });
});

// PUT: Update clinic data by ObjectID
const updateclinic = catchAsync(async (req, res) => {
  let clinicExist = await clinicService.findbyid(req.params.id);

  // Check clinic are found or not in database
  if (!clinicExist) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Clinic Are not Found.');
  }
  let updateClinicPayload = {};

  // Check Change clinic Name or not
  if (req.body.clinicName) {
    updateClinicPayload.clinicName = req.body.clinicName;
  }

  // Check Change clinic Address or not
  if (req.body.clinicAddress) {
    updateClinicPayload.clinicAddress = req.body.clinicAddress;
  }

  // Check Change clinic Description or not
  if (req.body.clinicDescription) {
    updateClinicPayload.clinicDescription = req.body.clinicDescription;
  }

  // Check Change clinic's openingHours or not
  if (req.body.openingHours) {
    const objectData = req.body.openingHours;
    const jsonObjectData = JSON.parse(objectData);
    updateClinicPayload.openingHours = jsonObjectData;
  }

  // Check Change clinic Image or not
  if (req.file) {
    updateClinicPayload.clinicImage = req.file.filename;
  }

  // Check Change clinic Service or not
  if (req.body.service) {
    const arrayData = req.body.service;
    const jsonArrayData = JSON.parse(arrayData);
    updateClinicPayload.service = jsonArrayData;
  }

  // Check Change clinic Daily Token limit or not
  if (req.body.dailyToken) {
    updateClinicPayload.dailyToken = req.body.dailyToken;
  }

  // Check Change clinic Category or not
  if (req.body.category) {
    updateClinicPayload.category = req.body.category;
  }

  // Check Change clinic location or not
  if (req.body.latitude && req.body.longitude) {
    updateClinicPayload.location = {
      type: 'Point',
      coordinates: [req.body.longitude, req.body.latitude],
    };
  }

  const updateuserclinic = await clinicService.updateClinic(clinicExist, updateClinicPayload);
  res.status(200).json({ success: true, msg: 'update clinic successfully', update: updateuserclinic });
});

// GET: Show clinic Token
const getclinictoken = catchAsync(async (req, res) => {
  const findById = await clinicService.findbyid(req.params.id);
  // Check clinic are found or not in database.
  if (!findById) {
    throw new ApiError(httpStatus.NOT_FOUND, 'clinic are not found');
  }
  const booktoken = await clinicService.findtoken(findById.dailyToken);
  res.status(200).json({ success: true, msg: 'clinic token get successfully', clinictoken: findById.dailyToken });
});

// Get Clinic by Location
const getlocationwiseclinic = catchAsync(async (req, res) => {
  const { search } = pick(req.query, ['search']);
  const options = pick(req.query, ['sortBy', 'limit', 'page']);

  options.sortBy = options.sortBy ? options.sortBy : '_id:desc';
  const skip = ((options.page || 1) - 1) * options.limit;

  let query = [
    {
      $geoNear: {
        near: {
          type: 'Point',
          coordinates: [Number(req.query.longitude), Number(req.query.latitude)],
        },
        distanceField: 'distance',
        maxDistance: 50000,
        spherical: true,
      },
    },
  ];

  if (search) {
    query.push({
      $match: {
        clinicName: { $regex: search ? search : '', $options: 'i' },
      },
    });
  }

  query.push(
    {
      $facet: {
        pagination: [
          {
            $count: 'totalResults',
          },
          {
            $addFields: {
              page: options.page,
              limit: options.limit,
              totalPages: {
                $ceil: {
                  $divide: ['$totalResults', options.limit],
                },
              },
            },
          },
        ],
        data: [
          { $skip: skip },
          {
            $limit: options.limit,
          },
        ],
      },
    },
    {
      $unwind: {
        path: '$pagination',
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $replaceRoot: {
        newRoot: {
          $mergeObjects: [
            {
              results: '$data',
            },
            '$pagination',
          ],
        },
      },
    }
  );
  const result = await clinicService.getlocationwiseclinic(query);

  if (result.results.length == 0) {
    res.status(404).json({ success: true, msg: 'No any clinics are at this Area.' });
  }

  res.status(200).json({
    success: true,
    msg: 'Location Wise data get successfully...!',
    data: result,
  });
});

// DELETE: Delete clinic by ObjectID
const deleteclinic = catchAsync(async (req, res) => {
  const findById = await clinicService.findbyid(req.params.id);
  if (!findById) {
    // Check clinic are found or not in database.
    throw new ApiError(httpStatus.NOT_FOUND, 'clinic are not found');
  }
  await clinicService.deleteclinic(req.params.id);
  res.status(200).json({ success: true, msg: 'clinic delete successfully' });
});

/**
 * Clinic List (Doctor Created)
 */
const getClinicForDoctor = catchAsync(async (req, res) => {
  const ClinicList = await clinicService.getClinicForDoctor(req.user._id);

  if (ClinicList.length == 0) {
    throw new ApiError(httpStatus.NOT_FOUND, 'No any clinic created by you');
  }
  const { search } = pick(req.query, ['search']);

  let filter = {
    doctor: req.user._id,
    deletedAt: null,
  };

  if (search) {
    filter.clinicName = new RegExp(search, 'i');
  }

  const options = pick(req.query, ['sortBy', 'limit', 'page']);

  options.populate = 'category, service, doctor';

  const clinic = await clinicService.getClinic(filter, options);

  res.status(httpStatus.OK).json({ success: true, msg: 'Clinic data get successfully', data: clinic });
});

/**
 * Clinic List (Doctor Created) drop down
 */
const getClinicDropDown = catchAsync(async (req, res) => {
  const ClinicList = await clinicService.getClinicForDoctor(req.user._id);

  if (ClinicList.length == 0) {
    throw new ApiError(httpStatus.NOT_FOUND, 'No any clinic created by you');
  }

  const clinic = await clinicService.getClinicDropDown(req.user._id);

  res.status(httpStatus.OK).json({ success: true, msg: 'Clinic data get successfully', data: clinic });
});

const clinicAppointmentHistory = catchAsync(async (req, res) => {
  const { search, start_date, end_date } = pick(req.query, ['search', 'start_date', 'end_date']);
  const options = pick(req.query, ['sortBy', 'limit', 'page']);

  const pagination = {
    limit: Number(options.limit),
    page: Number(options.page),
  };

  const skip = ((pagination.page || 1) - 1) * pagination.limit;

  let filter = {
    clinic: mongoose.Types.ObjectId(req.params.id),
  };

  if (start_date && end_date) {
    filter.createdAt = {
      $gte: new Date(start_date),
      $lte: new Date(`${end_date} 23:59:59`),
    };
  }

  filter.$or = [{ createdAt: { $lt: moment().startOf('day').toDate() } }, { serviceStatus: 'Complate' }];

  const query = [
    {
      $match: {
        ...filter,
      },
    },
    {
      $lookup: {
        from: 'users',
        localField: 'user',
        foreignField: '_id',
        as: 'user',
      },
    },
    {
      $unwind: {
        path: '$user',
        preserveNullAndEmptyArrays: true,
      },
    },
  ];

  if (search) {
    query.push({
      $match: {
        'user.first_name': {
          $regex: search ? search : '',
          $options: 'i',
        },
      },
    });
  }

  query.push(
    {
      $facet: {
        pagination: [
          {
            $count: 'totalResults',
          },
          {
            $addFields: {
              page: pagination.page,
              limit: pagination.limit,
              totalPages: {
                $ceil: {
                  $divide: ['$totalResults', pagination.limit],
                },
              },
            },
          },
        ],
        data: [
          { $skip: skip },
          {
            $limit: pagination.limit,
          },
        ],
      },
    },
    {
      $unwind: {
        path: '$pagination',
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $replaceRoot: {
        newRoot: {
          $mergeObjects: [
            {
              results: '$data',
            },
            '$pagination',
          ],
        },
      },
    }
  );

  const Clinicappointment = await clinicService.clinicAppointmentHistory(query);
  res.status(200).json({ success: true, msg: 'Get Clinic Appointment History Successfully...!', data: Clinicappointment });
});

// GET : get clinic dashboard
const getClinicDahboard = catchAsync(async (req, res) => {
  const findById = await clinicService.findbyid(req.params.id);
  // Check clinic are found or not in database.
  if (!findById) {
    throw new ApiError(httpStatus.NOT_FOUND, 'clinic are not found');
  }
  const getDashboard = await clinicService.getClinicDahboard(req.params.id);
  res.status(200).json({ success: true, msg: 'Get Clinic dashboard Successfully...!', data: getDashboard });
});

// All Modules are Exports from here 👇
module.exports = {
  createclinic,
  getAllclinic,
  getclinicuser,
  getclinictoken,
  updateclinic,
  getlocationwiseclinic,
  deleteclinic,
  getClinicForDoctor,
  getClinicUser,
  clinicAppointmentHistory,
  getClinicDahboard,
  getClinicDropDown,
};
