const catchAsync = require('../utils/catchAsync')
const httpStatus = require('http-status')
const serviceFeedbackservice = require('../services/serviceFeedback.service')

// create feedback function
const createservicefeedback = catchAsync(async (req, res) => {
    const feedback = await serviceFeedbackservice.createfeedback(req.params, req.body)
    res.status(httpStatus.CREATED).json({ success: true, msg: 'feedback create successfully', data: feedback })
})

// update feedback function
const updatefeedback = catchAsync(async (req, res) => {
    const updatefeedbacks = await serviceFeedbackservice.updatefeedback(req.params, req.body)
    res.status(httpStatus.OK).json({ success: true, msg: 'feedback update successfully', data: updatefeedbacks })
})

// delete feedback function
const deletefeedback = catchAsync(async (req, res) => {
    const ExistServiceFeedback = await serviceFeedbackservice.getServiceFeedbackByObjectId(req.params.id)
    if (!ExistServiceFeedback) {
        throw new ApiError(httpStatus.NOT_FOUND, 'feedback id are not found')
    }
    const deletefeedbackdata = await serviceFeedbackservice.deletefeedback(req.params.id)
    res.status(httpStatus.OK).json({ success: true, msg: 'your feedback delete successfully' })
})

// find all feedback 
const findallfeedback = catchAsync(async (req, res) => {
    const findfeedback = await serviceFeedbackservice.findallfeedback()
    res.status(httpStatus.OK).json({ success: true, msg: 'find all feedback successfully', data: findfeedback })
})

module.exports = {
    createservicefeedback,
    updatefeedback,
    deletefeedback,
    findallfeedback,
}