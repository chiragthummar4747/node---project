const httpStatus = require('http-status');
const ApiError = require('../utils/ApiError');
const catchAsync = require('../utils/catchAsync');
const moment = require('moment');
const dashboardService = require('../services/dashboard.service');

// get Dashboard data
const getDashboard = catchAsync(async (req, res) => res.status(httpStatus.OK).json({ success: true, data: await dashboardService.getDashboard(), msg: 'Dashboard data get successfully...!' }));

// get Dashboard charts
const dashboardChart = catchAsync(async (req, res) => {

  const patientDataQuery = [
    {
      $match: {
        createdAt: { $gt: new Date(moment().subtract(moment.duration({ 'days': 10 })).format()) }
      },
    },
    {
      $project: {
        createdAt:
        {
          $dateToString:
            { format: "%Y-%m-%d", date: "$createdAt" }
        },
      }
    },
    {
      $group: {
        _id: "$createdAt",
        count: { $sum: 1 }
      }
    }
  ]

  const clinicDataQuery = [
    {
      $lookup: {
        from: "clinics",
        localField: "clinic",
        foreignField: "_id",
        as: "clinic_details",
      },
    },
    {
      $unwind: {
        path: '$clinic_details',
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $group: {
        _id: "$clinic_details.clinicName",
        count: { $sum: 1 }
      }
    }
  ]

  const { patientData, clinicData, doctorArr } = await dashboardService.getPatientAndClinicData(patientDataQuery, clinicDataQuery)

  // patientChart 
  let start = moment().subtract(moment.duration({ 'days': 9 })).format('YYYY-MM-DD')
  let end = moment().format('YYYY-MM-DD')
  let patientChart = [];

  while (start <= end) {
    if (match = patientData.find((ele) => ele._id == start)) {
      patientChart.push({ _id: start, count: match.count })
    }
    else {
      patientChart.push({ _id: start, count: 0 })
    }
    start = moment(start).add(1, 'd').format('YYYY-MM-DD')
  }

  // clinicChart
  const clinicChart = [];

  doctorArr.forEach((ele) => {
    if (match = clinicData.find((element) => element._id == ele.clinicName)) {
      clinicChart.push({ _id: match._id, count: match.count })
    }
    else {
      clinicChart.push({ _id: ele.clinicName, count: 0 })
    }
  })
  res.status(httpStatus.OK).json({ success: true, data: { patientChart, clinicChart }, msg: 'Dashboard chart data get successfully...!' })

});

// All Modules are Exports from here 👇
module.exports = {
  getDashboard,
  dashboardChart
};
