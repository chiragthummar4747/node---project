const httpStatus = require('http-status');
const catchAsync = require('../utils/catchAsync');
const ApiError = require('../utils/ApiError');
const pick = require('../utils/pick');
const { role, User, doctor } = require('../models');
const { authService, userService, tokenService, emailService } = require('../services');

// POST: Register user
const register = catchAsync(async (req, res) => {
  const findmobile_no = await userService.getUserByMobileNo(req.body.mobile_no);
  // Find mobile number from database
  if (findmobile_no) {
    const otp = await tokenService.generateVerifyOtp(findmobile_no);

    res.status(httpStatus.CREATED).json({ msg: 'otp create successfully ', otp });
  }
  const user = await userService.createUser(req.body);
  const otp = await tokenService.generateVerifyOtp(user);

  res.status(httpStatus.CREATED).send({ msg: 'otp create successfully ', otp, user });
});

// POST: Login user
const login = catchAsync(async (req, res) => {
  const { email, password } = req.body;
  const user = await authService.loginUserWithEmailAndPassword(email, password);
  const tokens = await tokenService.generateAuthTokens(user);
  res.send({ user, tokens });
});

const logout = catchAsync(async (req, res) => {
  await authService.logout(req.body.refreshToken);
  res.status(httpStatus.NO_CONTENT).send();
});

const refreshTokens = catchAsync(async (req, res) => {
  const tokens = await authService.refreshAuth(req.body.refreshToken);
  res.send({ ...tokens });
});

const forgotPassword = catchAsync(async (req, res) => {
  const resetPasswordToken = await tokenService.generateResetPasswordToken(req.body.email);
  await emailService.sendResetPasswordEmail(req.body.email, resetPasswordToken);
  res.status(httpStatus.NO_CONTENT).send();
});

const resetPassword = catchAsync(async (req, res) => {
  await authService.resetPassword(req.query.token, req.body.password);
  res.status(httpStatus.NO_CONTENT).send();
});

const sendVerificationEmail = catchAsync(async (req, res) => {
  const verifyEmailToken = await tokenService.generateVerifyEmailToken(req.user);
  await emailService.sendVerificationEmail(req.user.email, verifyEmailToken);
  res.status(httpStatus.NO_CONTENT).send();
});

// POST: Verify OTP
const verifyotp = catchAsync(async (req, res) => {
  const user = await authService.verifmobile_no(req.query.otp);
  const token = await tokenService.generateAuthTokens(user);
  res.status(200).json({ success: true, msg: 'otp verification succesfully', data: user, token: token });
});

// GET: Get User Details from Access Token
const userDataFromToken = catchAsync(async (req, res) => {
  const roleData = await role.findOne({ _id: req.user.role });
  let userData;
  if ('User' == roleData.role) {
    userData = await User.findOne({ _id: req.user.id }).populate('role');
  }

  if ('Doctor' == roleData.role || 'Super Admin' == roleData.role) {
    userData = await doctor.findOne({ _id: req.user.id }).populate('role');
  }

  // const verifyToken = await
  res.status(httpStatus.OK).json({ status: true, msg: 'Verify Token Successfully...!', data: userData });
});

// PUT: Update user details by ObjectID
const updateuser = catchAsync(async (req, res) => {
  const user = await userService.ExistUser(req.params.id);
  // Find user by ObjectID
  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, 'userId are not found');
  } else {
    // Check image are upload or not.
    if (!req.file) {
      const update = await userService.updateuser(req.params.id, req.body);
      res.status([200]).send({ msg: 'user update successfully', update });
    } else {
      const update = await userService.updateuser(req.params.id, { ...req.body, userImage: req.file.filename });
      res.status([200]).send({ success: true, msg: 'user update successfully', data: update });
    }
  }
});

// GET: show all data from database
const getdata = catchAsync(async (req, res) => {
  const [userdata] = await userService.getuserdata(req.user);
  // Check Authenticate Token are found or not
  if (!userdata) {
    throw new ApiError(httpStatus.NOT_FOUND, 'token not found');
  }
  res.status(httpStatus.OK).send({ success: true, msg: 'get all data successfully', data: userdata });
});

/**
 * List of Patient
 */
const patientList = catchAsync(async (req, res) => {
  const { search } = pick(req.query, ['search']);
  let filter = {};
  const options = pick(req.query, ['sortBy', 'limit', 'page']);
  filter.role = req.query.role;
  filter.deletedAt = null;
  if (search) {
    filter.first_name = { $regex: search, $options: 'i' };
  }
  const result = await userService.patientList(filter, options);
  res.status(200).json({ success: true, mdg: 'Get All patient Successfully', data: result });
});

// DELETE: show all data from database(Soft delete)
const deleteUser = catchAsync(async (req, res) => {
  const ExistUser = await userService.getUserById(req.params.userId);
  if (!ExistUser) {
    throw new ApiError(httpStatus.NOT_FOUND, 'This User are not found');
  } else {
    const result = await userService.deleteUserById(req.params.userId);
    res.status(200).json({ success: true, mdg: 'Deleted Successfully', data: result });
  }
});

// All Modules are Exports from here 👇
module.exports = {
  register,
  login,
  logout,
  refreshTokens,
  forgotPassword,
  resetPassword,
  sendVerificationEmail,
  verifyotp,
  userDataFromToken,
  updateuser,
  getdata,
  patientList,
  deleteUser,
};
