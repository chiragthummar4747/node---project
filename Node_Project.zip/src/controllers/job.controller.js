const httpStatus = require('http-status');
const catchAsync = require('../utils/catchAsync');
const pick = require('../utils/pick');
const ApiError = require('../utils/ApiError');
const jobService = require('../services/job.service');

// POST: Add new Job in database
const createJob = catchAsync(async (req, res) => {

  const clinicExist = await jobService.clinicExist(req.body.clinicId);

  if (!clinicExist) throw new ApiError(httpStatus.NOT_FOUND, 'Clinic are not Found');

  const payload = { ...req.body };

  (req.file) ? payload.jobImage = req.file.filename : 0;

  const createJob = await jobService.createJob(payload);

  res.status(httpStatus.OK).json({ success: true, msg: 'Job created successfully', data: createJob });
});


// GET: show all Job data
const getAllJob = catchAsync(async (req, res) => {
  const options = pick(req.query, ['page', 'limit', 'sortBy']);

  const { search } = pick(req.query, ['search']);

  let filter = { deletedAt: null, isActive: true };

  (search) ? filter.title = { $regex: search, $options: 'i' } : 0

  options.populate = 'clinicId.doctor'

  const getAllJob = await jobService.getAllJob(filter, options);

  res.status(httpStatus.OK).json({ success: true, msg: 'All Job data get successfully', data: getAllJob });
});

// GET: Show Job data by ObjectID
const getJobById = catchAsync(async (req, res) => {
  const JobExist = await jobService.JobExist(req.params.jobId);
  // Check Job are found or not in database.
  if (!JobExist) throw new ApiError(httpStatus.NOT_FOUND, 'Job are not found');

  const getJobById = await jobService.getJobById(req.params.jobId);

  res.status(httpStatus.OK).json({ success: true, msg: 'Job data find successfully', data: getJobById });
});

// PUT: Update Doctor Profile
const updateJob = catchAsync(async (req, res) => {
  const JobExist = await jobService.JobExist(req.params.jobId);
  // Check Job are found or not in database.
  if (!JobExist) throw new ApiError(httpStatus.NOT_FOUND, 'Job are not found');

  const updateJob = (req.file) ? await jobService.updateJob(req.params.jobId, { ...req.body, jobImage: req.file.filename }) : await jobService.updateJob(req.params.jobId, req.body)

  res.status(httpStatus.CREATED).json({ success: true, msg: 'Update Your Job Successfully...!', data: updateJob })
});

// DELETE: Delete Job by ObjectID
const deleteJob = catchAsync(async (req, res) => {
  const JobExist = await jobService.JobExist(req.params.jobId);
  // Check Job are found or not in database.
  if (!JobExist) throw new ApiError(httpStatus.NOT_FOUND, 'Job are not found');

  await jobService.deleteJob(req.params.jobId);

  res.status(200).json({ success: true, msg: 'Job delete successfully' });
});

// All Modules are Exports from here 👇
module.exports = {
  createJob,
  getAllJob,
  getJobById,
  updateJob,
  deleteJob,
};
