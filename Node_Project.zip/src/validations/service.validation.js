const joi = require('joi');

// POST: Create a Services
const createservices = {
  body: joi.object().keys({
    services: joi.string().required(),
  }),
};

// GET: Get Service By Object Id
const getServiceByObjectId = {
  params: joi.object().keys({
    serviceId: joi.string(),
  }),
};

// UPDATE: Update Services by ObjectID
const updateService = {
  params: joi.object().keys({
    serviceId: joi.string(),
  }),
  body: joi.object().keys({
    services: joi.string(),
  }),
};

// DELETE: Delete Services by ObjectID
const deleteServices = {
  params: joi.object().keys({
    serviceId: joi.string(),
  }),
};

// All Modules are Exports from here 👇
module.exports = {
  createservices,
  getServiceByObjectId,
  updateService,
  deleteServices,
};
