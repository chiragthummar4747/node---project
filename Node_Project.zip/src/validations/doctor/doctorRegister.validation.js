const Joi = require('joi');
const { password, objectId } = require('../custom.validation');

const doctorRegister = {
  body: Joi.object().keys({
    email: Joi.string().email().required(),
  }),
};

const doctorLogin = {
  body: Joi.object().keys({
    email: Joi.string().email().required(),
    password: Joi.string().custom(password),
  }),
};

const updateDoctorProfile = {
  params: Joi.object().keys({
    id: Joi.string(),
  }),
  body: Joi.object().keys({
    first_name: Joi.string().allow(''),
    last_name: Joi.string().allow(''),
    mobile_no: Joi.number().allow(''),
    doctorImage: Joi.string().allow(''),
    address: Joi.string().allow(''),
    age: Joi.number().allow(''),
    role: Joi.string().allow(''),
  }),
};

// GET: show all doctor data
const getAlldoctor = {
  query: Joi.object().keys({
    search: Joi.string().allow(''),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
  }),
};

// GET: show all doctor data by id
const getDoctorProfile = {
  params: Joi.object().keys({
    doctorId: Joi.string().custom(objectId).required(),
  }),
  query: Joi.object().keys({
    search: Joi.string().allow(''),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
  }),
};

// All Modules are Exports from here 👇
module.exports = {
  doctorRegister,
  doctorLogin,
  updateDoctorProfile,
  getAlldoctor,
  getDoctorProfile,
};
