const Joi = require('joi');
const { objectId } = require('./custom.validation');

// POST: Create a offer
const createOffer = {
  body: Joi.object().keys({
    title: Joi.string().required(),
    description: Joi.string().allow(''),
    offerImage: Joi.string().allow(''),
    clinicId: Joi.string().custom(objectId).required(),
    isActive: Joi.boolean().allow('')
  }),
};

// GET: show all offer data
const getAllOffer = {
  query: Joi.object().keys({
    search: Joi.string().allow(''),
    sortBy: Joi.string().allow(''),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
  }),
};

// GET: Show offer data by ObjectID
const getOfferById = {
  param: Joi.object().keys({
    offerId: Joi.string().custom(objectId).required(),
  }),
};

// PUT: Update clinic data by ObjectID
const updateoffer = {
  param: Joi.object().keys({
    offerId: Joi.string().required(),
  }),
  body: Joi.object().keys({
    title: Joi.string().allow(''),
    description: Joi.string().allow(''),
    clinicId: Joi.string().custom(objectId).allow(''),
    offerImage: Joi.string().allow(''),
  }),
};

// All Modules are Exports from here 👇
module.exports = {
  createOffer,
  getAllOffer,
  getOfferById,
  updateoffer,
};
