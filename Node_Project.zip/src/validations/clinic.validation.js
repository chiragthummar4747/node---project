const joi = require('joi');
const { objectId } = require('./custom.validation');

// POST: Create a clinic
const createclinic = {
  body: joi.object().keys({
    clinicName: joi.string().required(),
    clinicAddress: joi.string().required(),
    openingHours: joi.string().required(),
    clinicDescription: joi.string(),
    latitude: joi.number(),
    longitude: joi.number(),
    category: joi.string().custom(objectId).required(),
    service: joi.string().required(),
    clinicImage: joi.string(),
    dailyToken: joi.number().required(),
  }),
};

// GET: show all clinic data
const getAllclinic = {
  query: joi.object().keys({
    search: joi.string().allow(''),
    sortBy: joi.string(),
    limit: joi.number().integer(),
    page: joi.number().integer(),
  }),
};

// GET: Show clinic data by ObjectID
const getclinicuser = {
  param: joi.object().keys({
    id: joi.string().required(),
  }),
};

// GET: Show clinic patient-list
const getClinicUser = {
  param: joi.object().keys({
    clinic_id: joi.string().required(),
  }),
  query: joi.object().keys({
    search: joi.string().allow(''),
    limit: joi.number().integer().allow(''),
    page: joi.number().integer().allow(''),
  }),
};

// PUT: Update clinic data by ObjectID
const updateclinic = {
  param: joi.object().keys({
    id: joi.string().required(),
  }),
  body: joi.object().keys({
    clinicName: joi.string(),
    clinicAddress: joi.string(),
    clinicDescription: joi.string(),
    openingHours: joi.string(),
    category: joi.string().custom(objectId),
    service: joi.string(),
    clinicImage: joi.string(),
    latitude: joi.number(),
    longitude: joi.number(),
    dailyToken: joi.number(),
  }),
};

// GET: Show clinic Token
const getclinictoken = {
  param: joi.object().keys({
    id: joi.string().required(),
  }),
};

const getlocationwiseclinic = {
  query: joi.object().keys({
    search: joi.string().allow(''),
    sortBy: joi.string(),
    limit: joi.number().integer().allow(''),
    page: joi.number().integer().allow(''),
    latitude: joi.number(),
    longitude: joi.number(),
  }),
};

// DELETE: Delete clinic by ObjectID
const deleteclinic = {
  param: joi.object().keys({
    id: joi.string().required(),
  }),
};

const queryClinic = {
  query: joi.object().keys({
    search: joi.string().allow(''),
    sortBy: joi.string(),
    limit: joi.number().integer().allow(''),
    page: joi.number().integer().allow(''),
  }),
};

const clinicAppointmentHistory = {
  param: joi.object().keys({
    id: joi.string(),
  }),
  query: joi.object().keys({
    search: joi.string().allow(''),
    sortBy: joi.string(),
    limit: joi.number().integer(),
    page: joi.number().integer(),
    start_date: joi.string().allow(''),
    end_date: joi.string().allow(''),
  }),
};

// All Modules are Exports from here 👇
module.exports = {
  createclinic,
  getAllclinic,
  getclinicuser,
  updateclinic,
  getclinictoken,
  getlocationwiseclinic,
  deleteclinic,
  queryClinic,
  clinicAppointmentHistory,
  getClinicUser,
};
