const Joi = require('joi');
const { objectId } = require('./custom.validation');

// POST: Create a Job
const createJob = {
  body: Joi.object().keys({
    title: Joi.string().required(),
    description: Joi.string().allow(''),
    jobImage: Joi.string().allow(''),
    clinicId: Joi.string().custom(objectId).required(),
    isActive: Joi.boolean().allow('')
  }),
};

// GET: show all Job data
const getAllJob = {
  query: Joi.object().keys({
    search: Joi.string().allow(''),
    sortBy: Joi.string().allow(''),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
  }),
};

// GET: Show Job data by ObjectID
const getJobById = {
  param: Joi.object().keys({
    jobId: Joi.string().custom(objectId).required(),
  }),
};

// PUT: Update clinic data by ObjectID
const updateJob = {
  param: Joi.object().keys({
    jobId: Joi.string().required(),
  }),
  body: Joi.object().keys({
    title: Joi.string().allow(''),
    description: Joi.string().allow(''),
    clinicId: Joi.string().custom(objectId).allow(),
    jobImage: Joi.string().allow(''),
  }),
};

// All Modules are Exports from here 👇
module.exports = {
  createJob,
  getAllJob,
  getJobById,
  updateJob,
};
