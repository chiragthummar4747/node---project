const joi = require('joi');

// POST: Create a Role
const createroleuser = {
  body: joi.object().keys({
    role: joi.string().required(),
  }),
};

// All Modules are Exports from here 👇
module.exports = {
  createroleuser,
};
