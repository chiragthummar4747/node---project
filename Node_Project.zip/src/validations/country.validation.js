const joi = require('joi');
const { objectId } = require('./custom.validation');

// POST: Create a country
const createCountry = {
  body: joi.object().keys({
    country_name: joi.string().required(),
    country_code: joi.string().required(),
    country_currency: joi.string().required(),
    country_ISO: joi.string().required(),
  }),
};

// GET: Show All country data from database
const getCountry = {
  query: joi.object().keys({
    search: joi.string().allow(""),
    sortBy: joi.string(),
    limit: joi.number().integer(),
    page: joi.number().integer(),
  }),
};

// GET: Show Country data by ObjectID
const getCountryById = {
  param: joi.object().keys({
    id: joi.string().custom(objectId),
  }),
};

// PUT: Update Country data by ObjectID
const updateCountry = {
  param: joi.object().keys({
    id: joi.string().custom(objectId),
  }),
  body: joi.object().keys({
    country_name: joi.string(),
    country_code: joi.string(),
    country_currency: joi.string(),
    country_ISO: joi.string(),
  }),
};

// DELETE: Delete Country by ObjectID
const deleteCountry = {
  param: joi.object().keys({
    id: joi.string().custom(objectId),
  }),
};

// All Modules are Exports from here 👇
module.exports = {
  createCountry,
  getCountry,
  getCountryById,
  updateCountry,
  deleteCountry,
};
