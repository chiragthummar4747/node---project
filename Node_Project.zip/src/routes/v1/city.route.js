const express = require('express');
const validate = require('../../middlewares/validate');
const cityValidation = require('../../validations/city.validation');
const cityController = require('../../controllers/city.controller');

const router = express.Router();

router
  .route('/')
  // Seeder API for Add city
  // .post(cityController.AllCityList)

  // Add city
  .post(validate(cityValidation.createCity), cityController.createCity)
  // Get all City
  .get(validate(cityValidation.getCity), cityController.getCity);

router
  .route('/:cityId')
  // Get city by ObjectId
  .get(validate(cityValidation.getCityById), cityController.getCityById)
  // Update City
  .put(validate(cityValidation.updateCity), cityController.updateCity)
  // Delete City
  .delete(validate(cityValidation.deleteCity), cityController.deleteCity);

// Get data by Country.
router.route('/country/:countryID').get(validate(cityValidation.getCityByCountry), cityController.getCityByCountry);

module.exports = router;
