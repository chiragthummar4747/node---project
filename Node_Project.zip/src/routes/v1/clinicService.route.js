const express = require('express');
const validate = require('../../middlewares/validate');
const clinicServiceValidation = require('../../validations/clinicService.validation');
const clinicServiceController = require('../../controllers/clinicService.controller');

const router = express.Router();

router
    .route('/')
    // Add clinic's service
    .post(validate(clinicServiceValidation.createClinicService), clinicServiceController.createClinicService)
    // Get clinic's Service
    .get(validate(clinicServiceValidation.getClinicService), clinicServiceController.getClinicService)

module.exports = router;
