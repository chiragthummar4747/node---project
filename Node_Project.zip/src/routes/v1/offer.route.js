const express = require('express');
const validate = require('../../middlewares/validate');
const offerValidation = require('../../validations/offer.validation');
const offerController = require('../../controllers/offer.controller');
const imageUpload = require('../../middlewares/upload');
const { auth } = require('../../middlewares/auth');

const router = express.Router();

router
  .route('/')
  // create offer
  .post(auth('Doctor'), imageUpload.single('offerImage'), validate(offerValidation.createOffer), offerController.createOffer)
  // get all offers
  .get(auth('Doctor','Super Admin','User'), validate(offerValidation.getAllOffer), offerController.getAllOffer)

router
  .route('/:offerId')
  // get offer by objectId
  .get(auth('Doctor','Super Admin','User'), validate(offerValidation.getOfferById), offerController.getOfferById)
  // update offer
  .put(auth('Doctor'), imageUpload.single('offerImage'), validate(offerValidation.updateoffer), offerController.updateOffer)
  // delete offer
  .delete(auth('Doctor'), validate(offerValidation.getOfferById), offerController.deleteOffer)

module.exports = router;