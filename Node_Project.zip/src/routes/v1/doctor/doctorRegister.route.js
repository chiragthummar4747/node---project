const express = require('express');
const validate = require('../../../middlewares/validate');
const router = express.Router();
const doctorValidation = require('../../../validations/doctor/doctorRegister.validation');
const doctorController = require('../../../controllers/doctor/doctorRegister.controller');
const { auth } = require('../../../middlewares/auth');
const imageUpload = require('../../../middlewares/upload');

// Get doctor dashboard details
router.get('/doctorDashboard', auth('Doctor', 'Super Admin'), doctorController.getDoctorDashboard);

// invite doctor through super Admin
router.post(
  '/doctorRegisterBySuperAdmin',
  auth('Super Admin'),
  validate(doctorValidation.doctorRegister),
  doctorController.doctorRegister
);

// Doctor Login
router.post('/doctorLogin', validate(doctorValidation.doctorLogin), doctorController.doctorLogin);

// Get All doctor only super Admin
router.get('/getAllDoctor', validate(doctorValidation.getAlldoctor), doctorController.getAllDoctor);

// Update Doctor Profile
router.put(
  '/updateDoctorProfile/:id',
  auth('Doctor', 'Super Admin'),
  imageUpload.single('doctorImage'),
  validate(doctorValidation.updateDoctorProfile),
  doctorController.updateDoctorProfile
);

// Get doctor profile
router.get('/get-doctor-profile', auth('Doctor', 'Super Admin'), doctorController.getDoctorProfile);

// Get doctor profile through super Admin
router.get(
  '/get-doctor-profile/:doctorId',
  auth('Doctor', 'Super Admin'),
  validate(doctorValidation.getDoctorProfile),
  doctorController.getDoctorProfileById
);

module.exports = router;
