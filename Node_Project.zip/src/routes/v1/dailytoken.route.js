const express = require('express');
const validate = require('../../middlewares/validate');
const dailytokenValidation = require('../../validations/dailytoken.validation');
const dailytokenController = require('../../controllers/dailytoken.controller');
const { auth } = require('../../middlewares/auth');

const router = express.Router();

router
  .route('/')
  // Book token on clinic without socket
  .post(validate(dailytokenValidation.bookingtoken), dailytokenController.bookingtoken)
  // Get token data
  .get(validate(dailytokenValidation.getTokenData), dailytokenController.getTokenData);

router
  .route('/:clinic')
  // Change Token Status without socket
  .put(validate(dailytokenValidation.changeTokenStatus), dailytokenController.changeTokenStatus);

// Clinic wise get all appointment token details
router
  .route('/getTodayToken/:clinic')
  // Get All Today Token Data
  .get(auth('Doctor', 'Super Admin'), validate(dailytokenValidation.getAllToken), dailytokenController.getAllToken);

// Cancel Token without Socket
router.route('/cancelToken/:clinic').put(validate(dailytokenValidation.cancelToken), dailytokenController.cancelToken);

// Get Current Token Number without socket
router.route('/currentToken').get(dailytokenController.currentToken);

module.exports = router;
