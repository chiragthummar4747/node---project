const express = require('express');
const validate = require('../../middlewares/validate');
const clinicvalidation = require('../../validations/clinic.validation');
const cliniccontroller = require('../../controllers/clinic.controller');
const imageUpload = require('../../middlewares/upload');
const { auth } = require('../../middlewares/auth');
const router = express.Router();

router
  .route('/')
  // Add clinic
  .post(auth('Doctor', 'Super Admin'), imageUpload.single('clinicImage'), validate(clinicvalidation.createclinic), cliniccontroller.createclinic)
  // Get All clinic
  .get(validate(clinicvalidation.getAllclinic), cliniccontroller.getAllclinic);

router
  .route('/:id')
  // Delete clinic
  .delete(auth('Doctor'), validate(clinicvalidation.deleteclinic), cliniccontroller.deleteclinic)
  // Get clinic by ObjectId
  .get(auth('Doctor', 'User'), validate(clinicvalidation.getclinicuser), cliniccontroller.getclinicuser)
  // Update Clinic
  .put(imageUpload.single('clinicImage'), auth('Doctor'), validate(clinicvalidation.updateclinic), cliniccontroller.updateclinic);

router
  .route('/patient-list/:clinic_id')
  .get(auth('Doctor'), validate(clinicvalidation.getClinicUser), cliniccontroller.getClinicUser);
// Find how many token give this clinic
router.route('/findtoken/:id').get(auth('Doctor'), validate(clinicvalidation.getclinictoken), cliniccontroller.getclinictoken);

router
  .route('/location/getcity')
  // Get Clinic by location
  .get(validate(clinicvalidation.getlocationwiseclinic), cliniccontroller.getlocationwiseclinic);

// Get clinic of created by doctor
router.route('/doctor/clinics-drop-down').get(auth('Doctor'), cliniccontroller.getClinicDropDown);
router.route('/doctor/clinics').get(auth('Doctor'), validate(clinicvalidation.queryClinic), cliniccontroller.getClinicForDoctor);

// Get History of appointments
router
  .route('/appointment-history/:id')
  .get(auth('Doctor'), validate(clinicvalidation.clinicAppointmentHistory), cliniccontroller.clinicAppointmentHistory);

// Get clinic of created by doctor
router
  .route('/clinic-dashboard/:id')
  .get(auth('Doctor'), validate(clinicvalidation.getclinicuser), cliniccontroller.getClinicDahboard);

module.exports = router;
