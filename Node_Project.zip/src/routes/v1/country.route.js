const express = require('express');
const validate = require('../../middlewares/validate');
const countryValidation = require('../../validations/country.validation');
const countryController = require('../../controllers/country.controller');

const router = express.Router();

router
  .route('/')
  // Add Country
  .post(validate(countryValidation.createCountry), countryController.createCountry)
  // Get All Country
  .get(validate(countryValidation.getCountry), countryController.getCountry);

router
  .route('/:countryId')
  // Get Country by ObjectId
  .get(validate(countryValidation.getCountryById), countryController.getCountryById)
  // Update Country
  .put(validate(countryValidation.updateCountry), countryController.updateCountry)
  // Delete Country
  .delete(validate(countryValidation.deleteCountry), countryController.deleteCountry);

module.exports = router;
