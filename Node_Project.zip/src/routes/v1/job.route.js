const express = require('express');
const validate = require('../../middlewares/validate');
const jobValidation = require('../../validations/job.validation');
const jobController = require('../../controllers/job.controller');
const imageUpload = require('../../middlewares/upload');
const { auth } = require('../../middlewares/auth');

const router = express.Router();

router
  .route('/')
  // create job
  .post(auth('Doctor'), imageUpload.single('jobImage'), validate(jobValidation.createJob), jobController.createJob)
  // get all jobs
  .get(auth('Doctor','Super Admin','User'), validate(jobValidation.getAllJob), jobController.getAllJob)

router
  .route('/:jobId')
  // get job by objectId
  .get(auth('Doctor','Super Admin','User'), validate(jobValidation.getJobById), jobController.getJobById)
  // update job
  .put(auth('Doctor'), imageUpload.single('jobImage'), validate(jobValidation.updateJob), jobController.updateJob)
  // delete job
  .delete(auth('Doctor'), validate(jobValidation.getJobById), jobController.deleteJob)

module.exports = router;