const express = require('express')
const validate = require('../../middlewares/validate')
const servicefeedbackValidation = require('../../validations/serviceFeedback.validation')
const servicefeedbackController = require('../../controllers/serviceFeedback.controller')


const router = express.Router();

router
    .route('/:id')
    // After service Give Feedback
    .post(validate(servicefeedbackValidation.createservicefeedback), servicefeedbackController.createservicefeedback)
    // Update Feedback
    .put(validate(servicefeedbackValidation.updatefeedback), servicefeedbackController.updatefeedback)
    // Delete Feedback
    .delete(validate(servicefeedbackValidation.deletefeedback), servicefeedbackController.deletefeedback)

router
    .route('/')
    // Get all Feedback
    .get(servicefeedbackController.findallfeedback)
module.exports = router