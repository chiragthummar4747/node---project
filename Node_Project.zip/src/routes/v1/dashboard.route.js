const express = require('express');
const validate = require('../../middlewares/validate');
const serviceValidation = require('../../validations/service.validation');
const dashboardController = require('../../controllers/dashboard.controller');
const { auth } = require('../../middlewares/auth');

const router = express.Router();

router
  .route('/')
  // Get all dashboard details
  .get(auth("Super Admin"), dashboardController.getDashboard);

router
  .route('/dashboard-charts')
  // Get dashboard charts
  .get(auth("Doctor"), dashboardController.dashboardChart);

module.exports = router;
