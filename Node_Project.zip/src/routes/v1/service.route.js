const express = require('express');
const validate = require('../../middlewares/validate');
const serviceValidation = require('../../validations/service.validation');
const serviceController = require('../../controllers/service.controller');
const { auth } = require('../../middlewares/auth');

const router = express.Router();

router
  .route('/')
  // Add services
  .post(auth('Super Admin'), validate(serviceValidation.createservices), serviceController.createservices)
  // Get all Services
  .get(auth('Super Admin', 'Doctor', 'User'), serviceController.getService);

// Delete(Soft) Sevices
router
  .route('/:serviceId')
  // Get Service from Object Id
  .get(
    auth('Super Admin', 'Doctor', 'User'),
    validate(serviceValidation.getServiceByObjectId),
    serviceController.getServiceByObjectId
  )

  // Update Service Data
  .put(auth('Super Admin'), validate(serviceValidation.updateService), serviceController.updateService)

  // Delete Service Data
  .delete(auth('Super Admin'), validate(serviceValidation.deleteServices), serviceController.deleteservices);

module.exports = router;
