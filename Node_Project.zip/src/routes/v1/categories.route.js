const express = require('express');
const validate = require('../../middlewares/validate');
const categoriesValidation = require('../../validations/categories.validation');
const categoriesController = require('../../controllers/categories.controller');
const imageUpload = require('../../middlewares/upload');
const { auth } = require('../../middlewares/auth');

const router = express.Router();

router
  .route('/')
  // Create/Add categories with image
  .post(auth('Super Admin'), validate(categoriesValidation.createCategories), categoriesController.createCategories)
  // Get all Categories
  .get(
    auth('Doctor', 'Super Admin', 'User'),
    validate(categoriesValidation.getCategories),
    categoriesController.getCategories
  );

router
  .route('/:id')
  // Get category by ObjectId
  .get(
    auth('Doctor', 'Super Admin', 'User'),
    validate(categoriesValidation.getCategoriesById),
    categoriesController.getCategoriesById
  )
  // Update Category
  .put(auth('Super Admin'), validate(categoriesValidation.updateCategories), categoriesController.updateCategories)
  // Delete Category
  .delete(auth('Super Admin'), validate(categoriesValidation.deleteCategories), categoriesController.deleteCategories);

module.exports = router;
