const passport = require('passport');
const httpStatus = require('http-status');
const ApiError = require('../utils/ApiError');
const jwt = require('jsonwebtoken');
const config = require('../config/config');
const role = require('../models/role.model');

const verifyCallback = (req, resolve, reject, requiredRights) => async (err, user, info) => {
  if (err || info || !user) {
    return reject(new ApiError(httpStatus.UNAUTHORIZED, 'Please authenticate'));
  }
  if (!requiredRights.includes((await role.findOne({ _id: user.role })).role)) {
    return reject(new ApiError(httpStatus.FORBIDDEN, `FORBIDDEN`));
  }
  req.user = user;
  resolve();
};

const auth =
  (...requiredRights) =>
  async (req, res, next) => {
    return new Promise((resolve, reject) => {
      passport.authenticate('jwt', { session: false }, verifyCallback(req, resolve, reject, requiredRights))(req, res, next);
    })
      .then(() => next())
      .catch((err) => next(err));
  };

// Globaly SALT_KEY
global.SALT_KEY = 'C9ZuGZFSP29YH6XLSOPYubDE5Z7ZtVap';

// Authentication
const authSocketIO = async (socket, next) => {
  const { token } = socket.handshake.auth;
  if (!token) {
    const err = new Error('Access Denied');
    err.data = { content: 'Please retry later' }; // additional details
    next(err);
  } else {
    jwt.verify(token, config.jwt.secret, (error, decoded) => {
      if (error) {
        const err = new Error('Invalid Token');
        err.data = { content: 'Please retry later' }; // additional details
        next(err);
      } else {
        // eslint-disable-next-line no-param-reassign
        socket.user = decoded;
        next();
      }
    });
  }
};

module.exports = {
  auth,
  authSocketIO,
};
