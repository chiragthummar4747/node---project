const request = require('supertest');
// const facker = require('facker');
const httpStatus = require('http-status');
const ApiError = require('../../src/utils/ApiError');
const moment = require('moment');
const bcrypt = require('bcryptjs');
const app = require('../../src/app');
const auth = require('../../src/middlewares/auth');
const config = require('../../src/config/config');
const setupTestDB = require('../utils/setupTestDB');
const { service } = require('../../src/models');
const { roleRights } = require('../../src/config/roles');
const { tokenTypes } = require('../../src/config/tokens');

setupTestDB();

describe('Service Route', () => {
  describe('POST /v1/service', () => {
    let newService;
    beforeEach(() => {
      newService = {
        services: 'Teeth Clean',
      };
    });

    test('Should return 201 and Successfully Service create if request status is true.', async () => {
      const res = await request(app).post('/v1/service').send(newService).expect(httpStatus.CREATED);
      expect(res.body).toEqual({
        success: true,
        msg: expect.anything(),
        data: {
          id: expect.anything(),
          deletedAt: null,
          services: 'TEETH CLEAN',
          createdAt: expect.anything(),
          updatedAt: expect.anything(),
        },
      });
    });
  });
});
