#!/bin/bash
#replace this with the path of your project on the VPS
cd /var/www/html/otm/online-token-booking-api

#pull from the branch
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_ed25519

git pull

# followed by instructions specific to your project that you used to do manually
export NVM_DIR=~/.nvm
source ~/.nvm/nvm.sh
yarn

export PATH=~/.npm-global/bin:$PATH
source ~/.profile

pm2 restart 1